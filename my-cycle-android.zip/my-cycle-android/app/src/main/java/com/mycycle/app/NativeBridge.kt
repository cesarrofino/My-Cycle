package com.mycycle.app

import android.content.ContentValues
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.os.PowerManager
import android.provider.MediaStore
import android.provider.Settings
import android.util.Base64
import android.webkit.JavascriptInterface
import androidx.biometric.BiometricManager
import androidx.core.content.FileProvider
import org.json.JSONObject
import java.io.File

/** Ponte entre o JavaScript da app e o Android (exposta como window.AndroidBridge). */
class NativeBridge(private val a: MainActivity) {

    // ---------- Notificações ----------

    @JavascriptInterface
    fun syncReminders(json: String) {
        try {
            val o = JSONObject(json)
            val list = ArrayList<String>()
            val arr = o.optJSONArray("profiles")
            if (arr != null) for (i in 0 until arr.length()) list.add(arr.optString(i))
            Scheduler.sync(a, o, list)
        } catch (e: Exception) {
            // dados inválidos: ignora
        }
    }

    @JavascriptInterface
    fun status(): String {
        val pm = a.getSystemService(PowerManager::class.java)
        val battery = pm?.isIgnoringBatteryOptimizations(a.packageName) ?: false
        return JSONObject()
            .put("notif", Notifier.canPost(a))
            .put("exact", Scheduler.canExact(a))
            .put("battery", battery)
            .toString()
    }

    @JavascriptInterface
    fun requestNotificationPermission() {
        a.runOnUiThread { a.askNotificationPermission(false) }
    }

    @JavascriptInterface
    fun requestNotificationPermissionOnce() {
        a.runOnUiThread { a.askNotificationPermission(true) }
    }

    @JavascriptInterface
    fun openExactAlarmSettings() {
        a.runOnUiThread {
            try {
                if (Build.VERSION.SDK_INT >= 31) {
                    a.startActivity(
                        Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, Uri.parse("package:${a.packageName}"))
                    )
                }
            } catch (e: Exception) {
                a.openAppDetails()
            }
        }
    }

    @JavascriptInterface
    fun openBatterySettings() {
        a.runOnUiThread {
            try {
                a.startActivity(
                    Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${a.packageName}"))
                )
            } catch (e: Exception) {
                try {
                    a.startActivity(Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS))
                } catch (e2: Exception) {
                    a.openAppDetails()
                }
            }
        }
    }

    @JavascriptInterface
    fun sendTest(delaySeconds: Int) {
        Scheduler.test(a, delaySeconds)
    }

    // ---------- Ficheiros ----------

    @JavascriptInterface
    fun saveFile(name: String, mime: String, base64: String): Boolean {
        if (Build.VERSION.SDK_INT < 29) return false
        return try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val resolver = a.contentResolver
            val cv = ContentValues()
            cv.put(MediaStore.Downloads.DISPLAY_NAME, safeName(name))
            cv.put(MediaStore.Downloads.MIME_TYPE, mime)
            cv.put(MediaStore.Downloads.RELATIVE_PATH, Environment.DIRECTORY_DOWNLOADS)
            cv.put(MediaStore.Downloads.IS_PENDING, 1)
            val uri = resolver.insert(MediaStore.Downloads.EXTERNAL_CONTENT_URI, cv)
            if (uri == null) {
                false
            } else {
                resolver.openOutputStream(uri)?.use { it.write(bytes) }
                val done = ContentValues()
                done.put(MediaStore.Downloads.IS_PENDING, 0)
                resolver.update(uri, done, null, null)
                true
            }
        } catch (e: Exception) {
            false
        }
    }

    @JavascriptInterface
    fun shareFile(name: String, mime: String, base64: String) {
        try {
            val bytes = Base64.decode(base64, Base64.DEFAULT)
            val dir = File(a.cacheDir, "shared")
            dir.mkdirs()
            dir.listFiles()?.forEach { it.delete() }
            val f = File(dir, safeName(name))
            f.writeBytes(bytes)
            val uri = FileProvider.getUriForFile(a, "${a.packageName}.fileprovider", f)
            val send = Intent(Intent.ACTION_SEND)
            send.type = mime
            send.putExtra(Intent.EXTRA_STREAM, uri)
            send.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            a.runOnUiThread {
                try {
                    a.startActivity(Intent.createChooser(send, name))
                } catch (e: Exception) {
                    // sem aplicações para partilhar
                }
            }
        } catch (e: Exception) {
            // ignora
        }
    }

    private fun safeName(n: String): String = n.replace(Regex("[^A-Za-z0-9._-]"), "_")

    // ---------- Biometria ----------

    @JavascriptInterface
    fun biometricAvailable(): Boolean =
        BiometricManager.from(a).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_WEAK) ==
            BiometricManager.BIOMETRIC_SUCCESS

    @JavascriptInterface
    fun biometricAuth(reqId: String, title: String) {
        a.runOnUiThread { a.showBiometric(reqId.filter { it.isLetterOrDigit() }, title) }
    }

    // ---------- Aparência ----------

    @JavascriptInterface
    fun setBars(statusColor: String, navColor: String) {
        a.runOnUiThread { a.setBars(statusColor, navColor) }
    }
}
