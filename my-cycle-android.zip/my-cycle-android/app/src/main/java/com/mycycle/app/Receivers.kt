package com.mycycle.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.work.Worker
import androidx.work.WorkerParameters

class AlarmReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.getBooleanExtra(Scheduler.EXTRA_TEST, false)) {
            Scheduler.test(context, 0)
        }
        Scheduler.process(context)
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        Notifier.ensureChannel(context)
        Scheduler.enqueueWatchdog(context)
        Scheduler.process(context)
    }
}

class WatchdogWorker(context: Context, params: WorkerParameters) : Worker(context, params) {
    override fun doWork(): Result {
        Scheduler.process(applicationContext)
        return Result.success()
    }
}
