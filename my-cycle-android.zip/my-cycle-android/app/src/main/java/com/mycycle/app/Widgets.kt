package com.mycycle.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.view.View
import android.widget.RemoteViews
import org.json.JSONObject
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

/** Constrói e atualiza o widget com os dados guardados pelo JavaScript (funciona offline). */
object Widgets {
    const val ACTION_TICK = "com.mycycle.app.WIDGET_TICK"
    private const val REQ_TICK = 31
    private const val REQ_OPEN = 32
    private const val REQ_DAY = 33

    private data class Model(
        val label: String,
        val big: String,
        val unit: String,
        val sub: String,
        val btn: String,
        val showBtn: Boolean,
        val color: Int
    )

    private fun ids(ctx: Context): IntArray =
        AppWidgetManager.getInstance(ctx).getAppWidgetIds(ComponentName(ctx, CycleWidget::class.java))

    /** Atualiza todos os widgets colocados e agenda a próxima viragem de dia. */
    fun updateAll(ctx: Context) {
        try {
            val ids = ids(ctx)
            if (ids.isEmpty()) return
            update(ctx, AppWidgetManager.getInstance(ctx), ids)
            scheduleTick(ctx)
        } catch (e: Exception) {
            // nunca deve afetar os avisos
        }
    }

    fun update(ctx: Context, mgr: AppWidgetManager, ids: IntArray) {
        val m = model(ctx, LocalDate.now())
        for (id in ids) mgr.updateAppWidget(id, views(ctx, m))
    }

    // ---------- viragem de dia (meia-noite) ----------

    private fun tickIntent(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, REQ_TICK, Intent(ctx, CycleWidget::class.java).setAction(ACTION_TICK),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    fun scheduleTick(ctx: Context) {
        try {
            if (ids(ctx).isEmpty()) return
            val am = ctx.getSystemService(AlarmManager::class.java) ?: return
            val at = LocalDate.now().plusDays(1).atTime(0, 1)
                .atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()
            am.setAndAllowWhileIdle(AlarmManager.RTC, at, tickIntent(ctx))
        } catch (e: Exception) {
            // o updatePeriodMillis serve de rede de segurança
        }
    }

    fun cancelTick(ctx: Context) {
        try {
            ctx.getSystemService(AlarmManager::class.java)?.cancel(tickIntent(ctx))
        } catch (e: Exception) {
            // nada a fazer
        }
    }

    // ---------- dados ----------

    private fun parse(s: String?): LocalDate? =
        try {
            if (s.isNullOrBlank()) null else LocalDate.parse(s)
        } catch (e: Exception) {
            null
        }

    private fun dias(n: Long) = if (n == 1L) "$n dia" else "$n dias"

    private fun model(ctx: Context, today: LocalDate): Model {
        val brand = ctx.getColor(R.color.brand)
        val s: JSONObject = Store.active(ctx)
            ?: return Model("My Cycle+", "\u2665", "", "Abre a app para começar", "", false, brand)

        val color = try {
            val a = s.optString("accent", "")
            if (a.isBlank()) brand else Color.parseColor(a)
        } catch (e: Exception) {
            brand
        }

        if (s.optBoolean("hide", false)) {
            return Model("My Cycle+", "\u2665", "", "Toca para abrir", "", false, color)
        }

        var logged = false
        val arr = s.optJSONArray("logged")
        if (arr != null) for (i in 0 until arr.length()) if (arr.optString(i) == today.toString()) logged = true
        val btn = if (logged) "\u2713 Registado hoje" else "+ Registar hoje"

        if (s.optBoolean("pregOn", false)) {
            val lmp = parse(s.optString("lmp", ""))
            if (lmp != null) {
                val d = ChronoUnit.DAYS.between(lmp, today)
                if (d in 0L..300L) {
                    return Model("Gravidez", "${d / 7}", "semanas", "e ${dias(d % 7)}", btn, true, color)
                }
            }
            return Model("Gravidez", "\u2665", "", "Toca para abrir", btn, true, color)
        }
        if (s.optBoolean("postOn", false)) {
            return Model("Pós-parto", "\u2665", "", "Cuida de ti", btn, true, color)
        }

        val last = parse(s.optString("lastStart", ""))
            ?: return Model("My Cycle+", "\u2014", "", "Regista a tua menstruação", btn, true, color)

        val avg = s.optInt("avg", 28).coerceIn(15, 60).toLong()
        val day = ChronoUnit.DAYS.between(last, today) + 1
        val diff = ChronoUnit.DAYS.between(today, last.plusDays(avg))
        val sub = when {
            diff > 1L -> "Menstruação em ${dias(diff)}"
            diff == 1L -> "Menstruação amanhã"
            diff == 0L -> "Menstruação prevista para hoje"
            else -> "Atrasada há ${dias(-diff)}"
        }
        return Model("Dia do ciclo", "${maxOf(day, 1L)}", "", sub, btn, true, color)
    }

    // ---------- vista ----------

    private fun open(ctx: Context, action: String?, req: Int): PendingIntent {
        val i = Intent(ctx, MainActivity::class.java)
            .setAction("com.mycycle.app.WIDGET_" + (action ?: "OPEN").uppercase())
            .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
        if (action != null) i.putExtra(MainActivity.EXTRA_ACTION, action)
        return PendingIntent.getActivity(ctx, req, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
    }

    private fun views(ctx: Context, m: Model): RemoteViews {
        val rv = RemoteViews(ctx.packageName, R.layout.widget_cycle)
        rv.setInt(R.id.w_bg, "setColorFilter", m.color)
        rv.setTextViewText(R.id.w_label, m.label)
        rv.setTextViewText(R.id.w_big, m.big)
        rv.setTextViewText(R.id.w_unit, m.unit)
        rv.setViewVisibility(R.id.w_unit, if (m.unit.isEmpty()) View.GONE else View.VISIBLE)
        rv.setTextViewText(R.id.w_sub, m.sub)
        rv.setTextViewText(R.id.w_btn, m.btn)
        rv.setViewVisibility(R.id.w_btn, if (m.showBtn) View.VISIBLE else View.GONE)
        rv.setOnClickPendingIntent(R.id.w_root, open(ctx, null, REQ_OPEN))
        rv.setOnClickPendingIntent(R.id.w_btn, open(ctx, "day", REQ_DAY))
        return rv
    }
}
