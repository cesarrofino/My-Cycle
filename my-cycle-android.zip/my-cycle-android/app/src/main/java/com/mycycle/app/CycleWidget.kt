package com.mycycle.app

import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent

/** Widget do ecrã inicial: dia do ciclo, previsão da menstruação e atalho "Registar hoje". */
class CycleWidget : AppWidgetProvider() {

    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        Widgets.update(context, manager, ids)
        Widgets.scheduleTick(context)
    }

    override fun onAppWidgetOptionsChanged(
        context: Context, manager: AppWidgetManager, id: Int, newOptions: android.os.Bundle
    ) {
        Widgets.update(context, manager, intArrayOf(id))
    }

    override fun onEnabled(context: Context) {
        Widgets.scheduleTick(context)
    }

    override fun onDisabled(context: Context) {
        Widgets.cancelTick(context)
    }

    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Widgets.ACTION_TICK) {
            Widgets.updateAll(context)
        } else {
            super.onReceive(context, intent)
        }
    }
}
