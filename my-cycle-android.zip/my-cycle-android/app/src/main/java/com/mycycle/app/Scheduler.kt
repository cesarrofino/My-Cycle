package com.mycycle.app

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.work.ExistingPeriodicWorkPolicy
import androidx.work.PeriodicWorkRequestBuilder
import androidx.work.WorkManager
import org.json.JSONObject
import java.util.concurrent.TimeUnit

object Scheduler {
    private const val GRACE_MS = 12L * 3600L * 1000L
    private const val REQ_NEXT = 1
    private const val REQ_TEST = 2
    const val EXTRA_TEST = "test"

    /** Chamado quando o JavaScript envia os dados atualizados. */
    fun sync(ctx: Context, snap: JSONObject, profiles: List<String>) {
        Store.saveSnapshot(ctx, snap, profiles)
        val now = System.currentTimeMillis()
        val stored = Store.lastProcessed(ctx)
        // não dispara avisos "do passado", mas tolera 2 min para alarmes que chegam ligeiramente atrasados
        Store.setLastProcessed(ctx, maxOf(stored, now - 120_000L))
        process(ctx)
    }

    /** Mostra o que já devia ter sido mostrado e agenda o alarme seguinte. */
    @Synchronized
    fun process(ctx: Context) {
        val now = System.currentTimeMillis()
        var last = Store.lastProcessed(ctx)
        if (last == 0L || last > now) last = now

        val events = Engine.build(ctx, now)
        val due = events.filter { it.at > last && it.at <= now && now - it.at <= GRACE_MS }
        Store.setLastProcessed(ctx, now)

        for (e in due.takeLast(4)) {
            Notifier.show(ctx, e.id.hashCode(), e.title, e.body, e.action)
        }
        rearm(ctx, events, now)
        Widgets.updateAll(ctx)
    }

    private fun nextPending(ctx: Context): PendingIntent =
        PendingIntent.getBroadcast(
            ctx, REQ_NEXT, Intent(ctx, AlarmReceiver::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

    private fun rearm(ctx: Context, events: List<Event>, now: Long) {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val pi = nextPending(ctx)
        val next = events.firstOrNull { it.at > now }
        if (next == null) {
            am.cancel(pi)
            return
        }
        setAlarm(am, next.at, pi)
    }

    fun canExact(ctx: Context): Boolean {
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return false
        return if (Build.VERSION.SDK_INT >= 31) am.canScheduleExactAlarms() else true
    }

    private fun setAlarm(am: AlarmManager, at: Long, pi: PendingIntent) {
        try {
            if (Build.VERSION.SDK_INT >= 31 && !am.canScheduleExactAlarms()) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            } else {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            }
        } catch (e: SecurityException) {
            am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        }
    }

    /** Notificação de teste, imediata ou daqui a N segundos (com a app fechada). */
    fun test(ctx: Context, delaySeconds: Int) {
        if (delaySeconds <= 0) {
            Notifier.show(ctx, 9001, "My Cycle+", "Notificação de teste ♥ Está tudo a funcionar.", null)
            return
        }
        val am = ctx.getSystemService(AlarmManager::class.java) ?: return
        val i = Intent(ctx, AlarmReceiver::class.java).putExtra(EXTRA_TEST, true)
        val pi = PendingIntent.getBroadcast(
            ctx, REQ_TEST, i, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        setAlarm(am, System.currentTimeMillis() + delaySeconds * 1000L, pi)
    }

    /** Rede de segurança: de 6 em 6 horas volta a verificar/agendar (útil em telemóveis que matam alarmes). */
    fun enqueueWatchdog(ctx: Context) {
        val req = PeriodicWorkRequestBuilder<WatchdogWorker>(6, TimeUnit.HOURS).build()
        WorkManager.getInstance(ctx)
            .enqueueUniquePeriodicWork("cycle_watchdog", ExistingPeriodicWorkPolicy.KEEP, req)
    }
}
