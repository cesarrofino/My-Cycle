package com.mycycle.app

import android.app.Application

class App : Application() {
    override fun onCreate() {
        super.onCreate()
        Notifier.ensureChannel(this)
        Scheduler.enqueueWatchdog(this)
    }
}
