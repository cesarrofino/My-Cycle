package com.mycycle.app

import android.Manifest
import android.annotation.SuppressLint
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.webkit.PermissionRequest
import android.webkit.ValueCallback
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebResourceResponse
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.OnBackPressedCallback
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.core.content.ContextCompat
import androidx.core.content.FileProvider
import androidx.core.graphics.ColorUtils
import androidx.core.view.WindowCompat
import androidx.webkit.WebViewAssetLoader
import java.io.File

class MainActivity : AppCompatActivity() {

    companion object {
        const val EXTRA_ACTION = "a"
        const val HOST = "appassets.androidplatform.net"
        const val START_URL = "https://$HOST/assets/www/index.html"
    }

    private lateinit var web: WebView
    private var fileCallback: ValueCallback<Array<Uri>>? = null
    private var captureUri: Uri? = null
    private var permissionRequest: PermissionRequest? = null
    private var afterCameraPermission: (() -> Unit)? = null
    private var pendingAction: String? = null
    private var askedNotifThisRun = false

    private val pickFile = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val cb = fileCallback
        fileCallback = null
        cb?.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(r.resultCode, r.data))
    }

    private val takePhoto = registerForActivityResult(ActivityResultContracts.TakePicture()) { ok ->
        val cb = fileCallback
        fileCallback = null
        val u = captureUri
        cb?.onReceiveValue(if (ok && u != null) arrayOf(u) else null)
    }

    private val cameraPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        val req = permissionRequest
        permissionRequest = null
        if (req != null) {
            if (granted) req.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE)) else req.deny()
        }
        val next = afterCameraPermission
        afterCameraPermission = null
        if (next != null) {
            if (granted) {
                next()
            } else {
                fileCallback?.onReceiveValue(null)
                fileCallback = null
            }
        }
    }

    private var openSettingsIfDenied = false
    private val notifPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            web.evaluateJavascript("window.syncNative&&window.syncNative()", null)
        } else if (openSettingsIfDenied) {
            openNotificationSettings()
        }
        openSettingsIfDenied = false
    }

    /** Bloqueia capturas de ecrã e esconde o conteúdo na lista de apps recentes. */
    fun applySecure(on: Boolean) {
        val flag = android.view.WindowManager.LayoutParams.FLAG_SECURE
        if (on) window.setFlags(flag, flag) else window.clearFlags(flag)
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        WindowCompat.setDecorFitsSystemWindows(window, true)
        applySecure(getSharedPreferences("mycycle_prefs", MODE_PRIVATE).getBoolean("secure", false))

        web = WebView(this)
        web.setBackgroundColor(ContextCompat.getColor(this, R.color.app_bg))
        web.overScrollMode = View.OVER_SCROLL_NEVER
        setContentView(web)
        window.setBackgroundDrawableResource(R.color.app_bg) // tira o splash nativo do fundo depois de arrancar

        val s = web.settings
        s.javaScriptEnabled = true
        s.domStorageEnabled = true
        s.allowFileAccess = false
        s.allowContentAccess = false
        s.mediaPlaybackRequiresUserGesture = false
        s.setSupportZoom(false)
        s.builtInZoomControls = false
        s.cacheMode = WebSettings.LOAD_DEFAULT

        web.addJavascriptInterface(NativeBridge(this), "AndroidBridge")

        val loader = WebViewAssetLoader.Builder()
            .setDomain(HOST)
            .addPathHandler("/assets/", WebViewAssetLoader.AssetsPathHandler(this))
            .build()

        web.webViewClient = object : WebViewClient() {
            override fun shouldInterceptRequest(view: WebView, request: WebResourceRequest): WebResourceResponse? =
                loader.shouldInterceptRequest(request.url)

            override fun shouldOverrideUrlLoading(view: WebView, request: WebResourceRequest): Boolean {
                val u = request.url
                if (u.host == HOST) return false
                try {
                    startActivity(Intent(Intent.ACTION_VIEW, u))
                } catch (e: Exception) {
                    // sem aplicação para abrir
                }
                return true
            }

            override fun onPageFinished(view: WebView, url: String?) {
                val act = pendingAction
                if (act != null) {
                    pendingAction = null
                    dispatchAction(act)
                }
            }
        }

        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest) {
                runOnUiThread {
                    val wantsVideo = request.resources.contains(PermissionRequest.RESOURCE_VIDEO_CAPTURE)
                    if (request.origin.host != HOST || !wantsVideo) {
                        request.deny()
                        return@runOnUiThread
                    }
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        request.grant(arrayOf(PermissionRequest.RESOURCE_VIDEO_CAPTURE))
                    } else {
                        permissionRequest = request
                        cameraPermission.launch(Manifest.permission.CAMERA)
                    }
                }
            }

            override fun onShowFileChooser(
                webView: WebView,
                filePathCallback: ValueCallback<Array<Uri>>,
                params: FileChooserParams
            ): Boolean {
                fileCallback?.onReceiveValue(null)
                fileCallback = filePathCallback

                val wantsImage = params.acceptTypes.any { it.startsWith("image") }
                if (params.isCaptureEnabled && wantsImage) {
                    val dir = File(cacheDir, "captures")
                    dir.mkdirs()
                    val f = File(dir, "cap_${System.currentTimeMillis()}.jpg")
                    val uri = FileProvider.getUriForFile(this@MainActivity, "$packageName.fileprovider", f)
                    captureUri = uri
                    val launch = { takePhoto.launch(uri) }
                    if (ContextCompat.checkSelfPermission(this@MainActivity, Manifest.permission.CAMERA) ==
                        PackageManager.PERMISSION_GRANTED
                    ) {
                        launch()
                    } else {
                        afterCameraPermission = { launch() }
                        cameraPermission.launch(Manifest.permission.CAMERA)
                    }
                } else {
                    try {
                        pickFile.launch(params.createIntent())
                    } catch (e: Exception) {
                        fileCallback = null
                        filePathCallback.onReceiveValue(null)
                    }
                }
                return true
            }
        }

        onBackPressedDispatcher.addCallback(this, object : OnBackPressedCallback(true) {
            override fun handleOnBackPressed() {
                if (web.canGoBack()) web.goBack() else finish()
            }
        })

        pendingAction = actionFrom(intent)
        if (savedInstanceState == null || web.restoreState(savedInstanceState) == null) web.loadUrl(START_URL)
    }

    override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        web.saveState(outState)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        setIntent(intent)
        val act = actionFrom(intent)
        if (act != null) dispatchAction(act)
    }

    override fun onResume() {
        super.onResume()
        web.onResume()
        web.evaluateJavascript("window.nativeResume&&window.nativeResume()", null)
    }

    override fun onPause() {
        web.onPause()
        super.onPause()
    }

    override fun onDestroy() {
        web.removeJavascriptInterface("AndroidBridge")
        super.onDestroy()
    }

    private fun actionFrom(i: Intent?): String? {
        val a = i?.getStringExtra(EXTRA_ACTION)
        return if (a == "day" || a == "start") a else null
    }

    private fun dispatchAction(a: String) {
        web.evaluateJavascript("window.nativeAction&&window.nativeAction('$a')", null)
    }

    // ---------- chamadas vindas da NativeBridge (já na thread principal) ----------

    fun askNotificationPermission(onlyOncePerRun: Boolean) {
        if (Notifier.canPost(this)) return
        if (onlyOncePerRun) {
            if (askedNotifThisRun) return
            askedNotifThisRun = true
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) !=
            PackageManager.PERMISSION_GRANTED
        ) {
            openSettingsIfDenied = !onlyOncePerRun
            notifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else if (!onlyOncePerRun) {
            openNotificationSettings()
        }
    }

    fun openNotificationSettings() {
        try {
            startActivity(
                Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS).putExtra(Settings.EXTRA_APP_PACKAGE, packageName)
            )
        } catch (e: Exception) {
            openAppDetails()
        }
    }

    fun openAppDetails() {
        try {
            startActivity(
                Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:$packageName"))
            )
        } catch (e: Exception) {
            // nada a fazer
        }
    }

    fun showBiometric(reqId: String, title: String) {
        val executor = ContextCompat.getMainExecutor(this)
        val prompt = BiometricPrompt(this, executor, object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(result: BiometricPrompt.AuthenticationResult) {
                web.evaluateJavascript("window.__bio&&window.__bio('$reqId',true)", null)
            }

            override fun onAuthenticationError(errorCode: Int, errString: CharSequence) {
                web.evaluateJavascript("window.__bio&&window.__bio('$reqId',false)", null)
            }
        })
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle(title)
            .setNegativeButtonText("Cancelar")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_WEAK)
            .build()
        prompt.authenticate(info)
    }

    fun setBars(statusColor: String, navColor: String) {
        try {
            val sc = Color.parseColor(statusColor.trim())
            val nc = Color.parseColor(navColor.trim())
            window.statusBarColor = sc
            window.navigationBarColor = nc
            val ctrl = WindowCompat.getInsetsController(window, web)
            ctrl.isAppearanceLightStatusBars = ColorUtils.calculateLuminance(sc) > 0.5
            ctrl.isAppearanceLightNavigationBars = ColorUtils.calculateLuminance(nc) > 0.5
        } catch (e: Exception) {
            // cor inválida: mantém
        }
    }
}
