package com.mycycle.app

import android.content.Context
import org.json.JSONObject
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.temporal.ChronoUnit

data class Event(val id: String, val at: Long, val title: String, val body: String, val action: String?)

/**
 * Calcula, a partir dos dados do ciclo, todos os lembretes dos próximos dias.
 * É determinístico: mesmo com a app fechada durante meses, os avisos continuam a ser gerados.
 */
object Engine {
    private val MONTHS = arrayOf(
        "janeiro", "fevereiro", "março", "abril", "maio", "junho",
        "julho", "agosto", "setembro", "outubro", "novembro", "dezembro"
    )

    private fun pt(d: LocalDate) = "${d.dayOfMonth} de ${MONTHS[d.monthValue - 1]}"
    private fun plural(n: Long, s: String, p: String) = "$n ${if (n == 1L) s else p}"

    private fun parse(s: String?): LocalDate? =
        try {
            if (s.isNullOrBlank()) null else LocalDate.parse(s)
        } catch (e: Exception) {
            null
        }

    private fun atHour(d: LocalDate, h: Int): Long =
        d.atTime(h.coerceIn(0, 23), 0).atZone(ZoneId.systemDefault()).toInstant().toEpochMilli()

    fun build(ctx: Context, nowMs: Long, horizonDays: Long = 75): List<Event> {
        val snaps = Store.snapshots(ctx).ifEmpty { listOf(JSONObject()) }
        val multi = snaps.size > 1
        val out = ArrayList<Event>()
        val zone = ZoneId.systemDefault()
        val today = Instant.ofEpochMilli(nowMs).atZone(zone).toLocalDate()
        val firstDay = today.minusDays(1)
        val lastDay = today.plusDays(horizonDays)

        for (s in snaps) {
            val pid = s.optString("pid", "p1")
            val name = s.optString("name", "")
            val hide = s.optBoolean("hide", false)
            val rem = s.optJSONObject("rem") ?: JSONObject()
            val hour = rem.optInt("hour", 9)
            val dailyOn = rem.optBoolean("daily", true)
            val hMorning = rem.optInt("h1", 8)
            val hAfternoon = rem.optInt("h2", 14)
            val hNight = rem.optInt("h3", 21)

            fun add(id: String, day: LocalDate, h: Int, title: String, body: String, action: String?) {
                if (day.isBefore(firstDay) || day.isAfter(lastDay)) return
                val t = when {
                    hide -> "Lembrete"
                    multi && name.isNotBlank() -> "$title · $name"
                    else -> title
                }
                val b = if (hide) "Tens um lembrete." else body
                out.add(Event("$pid|$id", atHour(day, h), t, b, action))
            }

            val pregOn = s.optBoolean("pregOn", false)
            val postOn = s.optBoolean("postOn", false)

            // Consultas pré-natais: 2 dias antes, 1 dia antes e no próprio dia
            if (pregOn) {
                val appts = s.optJSONArray("appts")
                if (appts != null) {
                    for (i in 0 until appts.length()) {
                        val a = appts.optJSONObject(i) ?: continue
                        val d = parse(a.optString("d")) ?: continue
                        val aid = a.optString("id", "") + a.optString("d")
                        val t = a.optString("t", "")
                        val n = a.optString("n", "")
                        val detail = pt(d) +
                            (if (t.isNotBlank()) " às $t" else "") +
                            (if (n.isNotBlank()) " — $n" else "")
                        for (off in 2 downTo 0) {
                            val whenTxt = when (off) {
                                0 -> "hoje"
                                1 -> "amanhã"
                                else -> "em 2 dias"
                            }
                            add("c$aid:$off", d.minusDays(off.toLong()), hour, "Consulta pré-natal $whenTxt", detail, null)
                        }
                    }
                }
            }

            // Menstruação: previsão, início e atraso
            val last = parse(s.optString("lastStart", ""))
            if (!pregOn && !postOn && last != null) {
                val avg = s.optInt("avg", 28).coerceIn(15, 60)
                val next = last.plusDays(avg.toLong())
                val days = rem.optInt("days", 2).toLong()

                if (rem.optBoolean("before", true) && days > 0) {
                    add(
                        "b$next", next.minusDays(days), hour, "Menstruação a caminho",
                        "Prevista para daqui a ${plural(days, "dia", "dias")} (${pt(next)}). Pode variar.", null
                    )
                }
                if (rem.optBoolean("start", true)) {
                    add(
                        "s$next", next, hour, "Já começou?",
                        "Regista o início da tua menstruação para melhorar as previsões.", "start"
                    )
                }
                if (rem.optBoolean("late", true)) {
                    for (m in longArrayOf(1L, 7L, 14L)) {
                        val extra = if (m >= 7L) {
                            " Se houver possibilidade de gravidez, faz um teste e fala com um profissional de saúde."
                        } else {
                            ""
                        }
                        add(
                            "l$next:$m", next.plusDays(m), hour, "Menstruação atrasada",
                            "A tua menstruação está atrasada há ${plural(m, "dia", "dias")}. Regista quando começar.$extra",
                            "start"
                        )
                    }
                }
            }

            // 3 lembretes por dia: manhã, tarde e noite
            if (dailyOn) {
                val logged = HashSet<String>()
                val arr = s.optJSONArray("logged")
                if (arr != null) for (k in 0 until arr.length()) logged.add(arr.optString(k))
                val last2 = parse(s.optString("lastStart", ""))
                val avg2 = s.optInt("avg", 28).coerceIn(15, 60)
                var i = 0L
                while (i <= horizonDays) {
                    val day = today.plusDays(i)
                    val ds = day.toString()

                    // Manhã
                    var morning = "Começa o dia a cuidar de ti. Regista como acordaste."
                    if (!pregOn && !postOn && last2 != null) {
                        val n = ChronoUnit.DAYS.between(last2, day) + 1
                        if (n >= 1) {
                            val next2 = last2.plusDays(avg2.toLong())
                            val left = ChronoUnit.DAYS.between(day, next2)
                            val extra = when {
                                left > 1L -> "menstruação prevista em ${pt(next2)}."
                                left == 1L -> "menstruação prevista para amanhã."
                                left == 0L -> "menstruação prevista para hoje."
                                else -> "menstruação atrasada ${plural(-left, "dia", "dias")}."
                            }
                            morning = "Dia $n do ciclo · $extra"
                        }
                    }
                    add("dm$ds", day, hMorning, "Bom dia ♥", morning, null)

                    // Tarde
                    add(
                        "dt$ds", day, hAfternoon, "Boa tarde ♥",
                        "Pausa rápida: bebe água e vê como te sentes. Regista sintomas ou humor se quiseres.", "day"
                    )

                    // Noite
                    if (logged.contains(ds)) {
                        add("dn$ds", day, hNight, "Boa noite ♥", "Dia registado ✓ Descansa bem.", null)
                    } else {
                        add(
                            "dn$ds", day, hNight, "Boa noite ♥",
                            "Como foi o teu dia? Regista os sintomas e o humor antes de dormir.", "day"
                        )
                    }
                    i++
                }
            }

            // Lembrete mensal de cópia de segurança (dia 1, às 10:00)
            if (rem.optBoolean("backup", true)) {
                var j = 0L
                while (j <= horizonDays) {
                    val day = today.plusDays(j)
                    if (day.dayOfMonth == 1) {
                        add(
                            "bk${day.year}-${day.monthValue}", day, 10, "Cópia de segurança ♥",
                            "Protege os teus dados: vai a Mais → Exportar os meus dados.", null
                        )
                    }
                    j++
                }
            }
        }
        out.sortBy { it.at }
        return out
    }
}
