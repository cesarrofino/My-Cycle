package com.mycycle.app

import android.content.Context
import org.json.JSONObject

/** Guarda, por perfil, o "snapshot" enviado pelo JavaScript (último ciclo, definições, consultas…). */
object Store {
    private const val FILE = "mycycle_native"
    private const val K_SNAPS = "snaps"
    private const val K_LAST = "last_processed"
    private const val K_ACTIVE = "active_pid"

    private fun sp(c: Context) = c.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    @Synchronized
    private fun readAll(c: Context): JSONObject =
        try {
            JSONObject(sp(c).getString(K_SNAPS, "{}") ?: "{}")
        } catch (e: Exception) {
            JSONObject()
        }

    @Synchronized
    fun saveSnapshot(c: Context, snap: JSONObject, keepProfiles: List<String>) {
        val all = readAll(c)
        val pid = snap.optString("pid", "p1")
        all.put(pid, snap)
        if (keepProfiles.isNotEmpty()) {
            val keys = ArrayList<String>()
            val it = all.keys()
            while (it.hasNext()) keys.add(it.next())
            for (k in keys) if (k != pid && !keepProfiles.contains(k)) all.remove(k)
        }
        sp(c).edit().putString(K_SNAPS, all.toString()).putString(K_ACTIVE, pid).commit()
    }

    @Synchronized
    fun snapshots(c: Context): List<JSONObject> {
        val all = readAll(c)
        val out = ArrayList<JSONObject>()
        val it = all.keys()
        while (it.hasNext()) {
            val o = all.optJSONObject(it.next())
            if (o != null) out.add(o)
        }
        return out
    }

    /** Perfil que está ativo na app (o último a sincronizar); usado pelo widget. */
    @Synchronized
    fun active(c: Context): JSONObject? {
        val pid = sp(c).getString(K_ACTIVE, null)
        val o = if (pid != null) readAll(c).optJSONObject(pid) else null
        return o ?: snapshots(c).firstOrNull()
    }

    @Synchronized
    fun lastProcessed(c: Context): Long = sp(c).getLong(K_LAST, 0L)

    @Synchronized
    fun setLastProcessed(c: Context, v: Long) {
        sp(c).edit().putLong(K_LAST, v).commit()
    }
}
