'use strict';
const $=s=>document.querySelector(s),$$=s=>[...document.querySelectorAll(s)];
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const d2n=s=>{const[a,b,c]=s.split('-').map(Number);return Math.round(Date.UTC(a,b-1,c)/864e5)};
const n2d=n=>new Date(n*864e5).toISOString().slice(0,10);
const p2=n=>String(n).padStart(2,'0');
const today=()=>{const d=new Date();return d.getFullYear()+'-'+p2(d.getMonth()+1)+'-'+p2(d.getDate())};
const MES=['janeiro','fevereiro','março','abril','maio','junho','julho','agosto','setembro','outubro','novembro','dezembro'];
const formatDate=(s,sh)=>{const[y,m,d]=s.split('-').map(Number);return d+' de '+MES[m-1]+(sh?'':' de '+y)};
const dm=s=>p2(+s.slice(8))+'/'+s.slice(5,7);
const validDate=s=>/^\d{4}-\d\d-\d\d$/.test(s||'')&&n2d(d2n(s))===s;
const plural=(n,a,b)=>n+' '+(Math.abs(n)===1?a:b);
const Q=[['normal','♥','Normal'],['bem','😊','Bem'],['cansada','😴','Cansada'],['colicas','😣','Cólicas'],['triste','😔','Triste'],['cabeca','🤕','Dor de cabeça'],['irritada','😡','Irritada'],['inchaco','💧','Inchaço']];
const MOOD=['Feliz','Normal','Triste','Irritada','Ansiosa','Sensível'],SYM=['Cólicas','Dor de cabeça','Dor lombar','Acne','Inchaço','Cansaço','Sensibilidade mamária','Náuseas'],FLOW=['Ligeiro','Moderado','Intenso'];
const MSG=['Hoje é um bom dia para cuidar de ti. ♥','Não te esqueças de descansar.','Escuta o teu corpo.','Cuida de ti com carinho.','Bebe água e respira fundo.','Um passo de cada vez.'];
/* ===== Perfis (vários utilizadores no mesmo telemóvel) ===== */
let DBN='fanny-app',ADDING=false,PREVID=null,PICKFROM='boot';
const PRget=()=>{try{return JSON.parse(localStorage.getItem('ff-profiles'))||null}catch(e){return null}},PRset=v=>localStorage.setItem('ff-profiles',JSON.stringify(v));
function profInit(){let l=PRget();if(!l||!l.length){l=[{id:'p1',db:'fanny-app'}];PRset(l)}let a=localStorage.getItem('ff-active');if(!l.find(x=>x.id===a)){a=l[0].id;localStorage.setItem('ff-active',a)}DBN=l.find(x=>x.id===a).db}
function profSync(){nbSoon();const l=PRget(),a=localStorage.getItem('ff-active'),c=l&&l.find(x=>x.id===a);if(!c)return;const nm=S.profile&&S.profile.name,lk=!!(S.cfg&&S.cfg.pin),th=(S.profile&&S.profile.thumb)||'';if(c.name!==nm||c.lk!==lk||(c.ph||'')!==th){c.name=nm;c.lk=lk;c.ph=th;PRset(l)}}
async function switchTo(id){localStorage.setItem('ff-active',id);profInit();try{db&&db.close()}catch(e){}await openDB();await load()}
function showPicker(from){PICKFROM=from||'boot';$('#lock').hidden=true;$('#ob').hidden=true;$('#nav').hidden=true;const l=PRget()||[];
$('#pkg').innerHTML=l.map(p=>`<button type="button" class="pk-i" data-a="pickP" data-id="${p.id}"><span class="pk-av"${p.ph?` style="background-image:url('${p.ph}');background-size:cover;background-position:center;color:transparent"`:''}>${esc((p.name||'+').trim().charAt(0).toUpperCase())}${p.lk?`<i class="pk-lk">${ic('lock')}</i>`:''}</span><b>${esc(p.name||'Novo perfil')}</b></button>`).join('')+(l.length<4?`<button type="button" class="pk-i pk-add" data-a="addP"><span class="pk-av">+</span><b>Adicionar perfil</b></button>`:'');
$('#pkx').hidden=PICKFROM==='boot';$('#pick').hidden=false}
async function afterSwitch(){V='home';REV=false;LASTV=null;$('#pick').hidden=true;if(!S.profile||!S.cycles.length){OB={};OB2={};OBS=0;ADDING=ADDING;return onb(1)}if(S.cfg.pin)showLock();else enter()}
async function cancelAdd(){const id=localStorage.getItem('ff-active'),cur=(PRget()||[]).find(x=>x.id===id);try{db.close()}catch(e){}
if(cur)await new Promise(r=>{const q=indexedDB.deleteDatabase(cur.db);q.onsuccess=q.onerror=q.onblocked=()=>r()});
PRset((PRget()||[]).filter(x=>x.id!==id));ADDING=false;localStorage.setItem('ff-active',PREVID||(PRget()[0]||{}).id||'p1');profInit();await openDB();await load();$('#ob').hidden=true;showPicker('boot')}
/* ===== base de dados (IndexedDB) ===== */
let db;
const openDB=()=>new Promise((res,rej)=>{const r=indexedDB.open(DBN,1);r.onupgradeneeded=()=>{const d=r.result;d.createObjectStore('profile',{keyPath:'id'});d.createObjectStore('cycles',{keyPath:'id',autoIncrement:true});d.createObjectStore('logs',{keyPath:'date'});d.createObjectStore('settings',{keyPath:'k'})};r.onsuccess=()=>{db=r.result;res()};r.onerror=()=>rej(r.error)});
const tx=(s,m,f)=>new Promise((res,rej)=>{const t=db.transaction(s,m),o=f(t.objectStore(s));t.oncomplete=()=>res(o&&o.result);t.onerror=()=>rej(t.error)});
const nbSoon=()=>{try{window.syncNative&&window.syncNative()}catch(e){}};
const dbAll=s=>tx(s,'readonly',o=>o.getAll()),dbPut=(s,v)=>tx(s,'readwrite',o=>o.put(v)).then(r=>{nbSoon();return r}),dbDel=(s,k)=>tx(s,'readwrite',o=>o.delete(k)).then(r=>{nbSoon();return r}),dbClr=s=>tx(s,'readwrite',o=>o.clear()).then(r=>{nbSoon();return r});
let S={profile:null,cycles:[],logs:{},cfg:{}};
async function load(){const p=await dbAll('profile');S.profile=p[0]||null;S.cycles=(await dbAll('cycles')).sort((a,b)=>d2n(a.start)-d2n(b.start));S.logs={};(await dbAll('logs')).forEach(l=>S.logs[l.date]=l);const c=(await dbAll('settings')).find(x=>x.k==='cfg');S.cfg=c?c.v:{};profSync()}
const saveCfg=async()=>{await dbPut('settings',{k:'cfg',v:S.cfg});profSync()};
