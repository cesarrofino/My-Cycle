/* ===== cálculos ===== */
function calculateCycleLength(i){const c=S.cycles;return i<c.length-1?d2n(c[i+1].start)-d2n(c[i].start):null}
const cycleLens=()=>S.cycles.map((_,i)=>calculateCycleLength(i)).filter(x=>x!==null);
function calculateAverageCycle(){const l=cycleLens().filter(x=>x>=15&&x<=60).slice(-6);return l.length?Math.round(l.reduce((a,b)=>a+b)/l.length):S.profile.cycleLen}
function calculatePeriodDuration(c){return c.end?d2n(c.end)-d2n(c.start)+1:null}
function avgPeriod(){const l=S.cycles.map(calculatePeriodDuration).filter(Boolean);return l.length?Math.round(l.reduce((a,b)=>a+b)/l.length):S.profile.periodLen}
const lastC=()=>S.cycles[S.cycles.length-1];
const calculateNextPeriod=()=>n2d(d2n(lastC().start)+calculateAverageCycle());
const daysUntilPeriod=()=>d2n(calculateNextPeriod())-d2n(today());
function calculatePredictionConfidence(){const l=cycleLens();if(l.length<2)return'low';const m=l.reduce((a,b)=>a+b)/l.length;return Math.sqrt(l.reduce((a,b)=>a+(b-m)**2,0)/l.length)>5?'approx':'ok'}
function calculateCyclePhase(){const c=lastC();if(!c)return null;const day=d2n(today())-d2n(c.start),cl=calculateAverageCycle(),pl=avgPeriod(),ov=cl-14;let n=day<pl?'Menstruação':day<ov-1?'Fase folicular':day<=ov+1?'Ovulação (estimativa)':day<cl?'Fase lútea':'Ciclo mais longo que o previsto';return{day,cl,pl,ov,n}}
/* ===== segurança PIN / biometria ===== */
async function hash(s){const salt=S.cfg.salt||(S.cfg.salt=Math.random().toString(36).slice(2)+Date.now());if(window.crypto&&crypto.subtle){const b=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(salt+s));return[...new Uint8Array(b)].map(x=>x.toString(16).padStart(2,'0')).join('')}let h=5381;for(const ch of salt+s)h=(h*33^ch.charCodeAt(0))>>>0;return'f'+h}
const b64=u=>btoa(String.fromCharCode(...new Uint8Array(u)));
async function bioReg(){if(NB&&NB.biometricAvailable()){const ok=await nbBio('Ativar biometria');if(ok){S.cfg.bio='native';await saveCfg()}return ok}try{const r=await navigator.credentials.create({publicKey:{challenge:crypto.getRandomValues(new Uint8Array(32)),rp:{name:'My Cycle+'},user:{id:crypto.getRandomValues(new Uint8Array(16)),name:'fanny',displayName:'Fanny'},pubKeyCredParams:[{type:'public-key',alg:-7},{type:'public-key',alg:-257}],authenticatorSelection:{authenticatorAttachment:'platform',userVerification:'required'},timeout:60000}});S.cfg.bio=b64(r.rawId);await saveCfg();return true}catch(e){return false}}
async function bioAuth(){if(NB&&S.cfg.bio==='native')return nbBio('Desbloquear My Cycle+');try{await navigator.credentials.get({publicKey:{challenge:crypto.getRandomValues(new Uint8Array(32)),allowCredentials:[{type:'public-key',id:Uint8Array.from(atob(S.cfg.bio),c=>c.charCodeAt(0))}],userVerification:'required',timeout:60000}});return true}catch(e){return false}}
