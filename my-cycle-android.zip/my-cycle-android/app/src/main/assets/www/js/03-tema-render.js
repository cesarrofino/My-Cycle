/* ===== UI base ===== */
let V='home',cm=(()=>{const d=new Date();return{y:d.getFullYear(),m:d.getMonth()}})();
const NAVOF={bbt:'more',qr:'more',gkick:'home',gweight:'home',gbag:'home',prof:'home',notif:'home',hist:'more',phases:'more',learn:'more',help:'more',sett:'more'};
const toast=m=>{const t=$('#toast');t.textContent=m;t.hidden=false;clearTimeout(toast.t);toast.t=setTimeout(()=>t.hidden=true,2800)};
const sheet=h=>{$('#pn').innerHTML=h;$('#sh').hidden=false};
const closeSheet=()=>{if(typeof scanStop==='function')scanStop();$('#sh').hidden=true};
const PAL={rosa:{d:'#7A2B45',m:'#B4566F',l:'#C9738D',s:'#FBF4F0',t:'#E9DEFA',c1:'#8A3552',c2:'#963F5C',lt:'#F3D5DF',dd:'#5A1F36',ln:'#F0E1E4',k:'#17111a'},azul:{d:'#0A4FD0',m:'#2F80ED',l:'#5AA2FF',s:'#F3F7FF',t:'#DCE9FF',c1:'#1F66E0',c2:'#3B7DF0',lt:'#D6E6FF',dd:'#08357F',ln:'#E1E9F8',k:'#0d1424'},roxo:{d:'#5B21B6',m:'#8B5CF6',l:'#A78BFA',s:'#F7F3FF',t:'#E8DEFD',c1:'#6D33C9',c2:'#7E48DB',lt:'#E6DCFF',dd:'#3B1580',ln:'#E9E1F8',k:'#141021'},branco:{d:'#2F3441',m:'#5B6372',l:'#8A92A3',s:'#F5F6F8',t:'#E7E9EE',c1:'#3F4655',c2:'#4C5465',lt:'#DDE1E8',dd:'#1B1E27',ln:'#E8EAEE',k:'#101216'}};
const CUSV=['--bg','--cd','--tx','--mu','--ac','--ac2','--wn','--ln','--sh','--g1','--g2','--g3','--sr','--ar','--h1','--h2','--h3','--tl1','--tl2','--tl3','--tw1','--tw2','--bl1','--bl2','--bl3','--t1','--t2','--t3','--dl1','--dl2','--dl3','--dw1','--dw2'];
const cHx=h=>{h=String(h||'').trim().replace('#','');if(h.length===3)h=h.replace(/./g,'$&$&');return/^[0-9a-f]{6}$/i.test(h)?'#'+h.toLowerCase():'#b4566f'};
const cusHex=()=>cHx(localStorage.getItem('ff-custom'));
const h2r=h=>{h=cHx(h).slice(1);return[0,2,4].map(i=>parseInt(h.slice(i,i+2),16))};
function r2hsl(r,g,b){r/=255;g/=255;b/=255;const M=Math.max(r,g,b),m=Math.min(r,g,b),l=(M+m)/2;let h=0,s=0;if(M!==m){const d=M-m;s=l>.5?d/(2-M-m):d/(M+m);h=M===r?(g-b)/d+(g<b?6:0):M===g?(b-r)/d+2:(r-g)/d+4;h*=60}return[h,s*100,l*100]}
function hsl(h,s,l){h=((h%360)+360)%360;s=Math.max(0,Math.min(100,s))/100;l=Math.max(0,Math.min(100,l))/100;const a=s*Math.min(l,1-l),f=n=>{const k=(n+h/30)%12;return l-a*Math.max(-1,Math.min(k-3,9-k,1))};return'#'+[f(0),f(8),f(4)].map(x=>Math.round(x*255).toString(16).padStart(2,'0')).join('')}
const lum=h=>{const[r,g,b]=h2r(h).map(v=>{v/=255;return v<=.03928?v/12.92:Math.pow((v+.055)/1.055,2.4)});return .2126*r+.7152*g+.0722*b};
const cWh=h=>1.05/(lum(h)+.05);
function cusB(hx){const[r,g,b]=h2r(hx),[H0,S0,L0]=r2hsl(r,g,b),H=Math.round(H0),S=Math.min(S0,88);let ac=Math.min(58,Math.max(40,L0)),g1=Math.max(18,ac-18);while(g1>14&&cWh(hsl(H,S,g1))<4.5)g1-=2;while(ac>g1+8&&cWh(hsl(H,S,ac))<3)ac-=2;return{H,S,sp:Math.min(S0,80),ac,g1}}
function cusPal(hx){const{H,S,sp,ac,g1}=cusB(hx);return{d:hsl(H,S,g1),m:hsl(H,S,ac),l:hsl(H,S,Math.min(75,ac+12)),s:hsl(H,sp*.9,96),t:hsl(H+25,sp*.8,92),c1:hsl(H,S,g1+4),c2:hsl(H,S,g1+8),lt:hsl(H,sp,91),dd:hsl(H,S,Math.max(12,g1-8)),ln:hsl(H,sp*.5,92),k:hsl(H,22,8)}}
function cVars(hx,dk){const{H,S,sp,ac,g1}=cusB(hx),G1=hsl(H,S,g1),G2=hsl(H,S,ac),G3=hsl(H,S,Math.min(75,ac+12)),rg=h2r(G1).join(','),ra=h2r(G2).join(',');
const V={'--g1':G1,'--g2':G2,'--g3':G3,'--sr':rg,'--ar':ra,'--h1':hsl(H,S,g1-5),'--h2':hsl(H,S,g1+9),'--h3':hsl(H,S,g1+24),'--tl1':hsl(H,sp,93),'--tl2':hsl(H+25,sp*.8,92),'--tl3':hsl(H,sp*.6,97),'--tw1':hsl(H,sp,91),'--tw2':hsl(H+25,sp*.8,91),'--bl1':'hsla('+H+','+sp+'%,72%,.55)','--bl2':'hsla('+(H+30)+','+sp*.9+'%,78%,.5)','--bl3':'hsla('+(H-25)+','+sp*.9+'%,82%,.55)','--t1':hsl(H,sp,93),'--t2':hsl(H,sp,88),'--t3':hsl(H,sp*.9,80)};
if(dk)Object.assign(V,{'--bg':hsl(H,22,8),'--cd':hsl(H,20,13),'--tx':hsl(H,35,94),'--mu':hsl(H,12,66),'--ac':hsl(H,Math.max(S,45),72),'--ac2':hsl(H+20,22,22),'--wn':hsl(H,55,82),'--ln':hsl(H,16,20),'--sh':'0 8px 28px rgba(0,0,0,.35)','--dl1':hsl(H,28,14),'--dl2':hsl(H,26,10),'--dl3':hsl(H,22,8),'--dw1':hsl(H,26,18),'--dw2':hsl(H,24,13)});
else Object.assign(V,{'--bg':hsl(H,Math.min(sp*.9,70),96),'--cd':'#ffffff','--tx':hsl(H,Math.min(sp,40)*.7,17),'--mu':hsl(H,Math.min(sp,30)*.5+6,50),'--ac':G2,'--ac2':hsl(H+25,sp*.8,92),'--wn':G1,'--ln':hsl(H,sp*.5,92),'--sh':'0 8px 28px rgba('+rg+',.1)'});return V}
function theme(){const t=localStorage.getItem('ff-theme')||'auto',c=localStorage.getItem('ff-color')||'rosa',E=document.documentElement,dk=t==='dark'||(t==='auto'&&!!window.matchMedia&&matchMedia('(prefers-color-scheme: dark)').matches);E.dataset.t=t;E.dataset.c=c;CUSV.forEach(v=>E.style.removeProperty(v));let P=PAL[c]||PAL.rosa;if(c==='custom'){const h=cusHex(),V=cVars(h,dk);for(const k in V)E.style.setProperty(k,V[k]);P=cusPal(h)}const m=document.querySelector('meta[name=theme-color]');if(m)m.content=dk?P.k:P.d;nbSoon()}
try{matchMedia('(prefers-color-scheme: dark)').addEventListener('change',()=>{if(localStorage.getItem('ff-color')==='custom')theme()})}catch(e){}
let LASTV=null,HI=0,POP=false,IGN=0,VS=[];const RT=['home','cal','diary','stats','more'];
function navHist(){if(LASTV===null){if(HI>0){IGN++;history.go(-HI)}HI=0;VS=[V];history.replaceState({v:V,i:0},'');LASTV=V;return}
if(V===LASTV)return;if(POP){LASTV=V;return}
const j=VS.lastIndexOf(V);
if(j>=0&&j<HI){IGN++;history.go(j-HI);HI=j;VS.length=j+1}
else if(RT.includes(V)&&RT.includes(LASTV)&&LASTV!=='home'){VS[HI]=V;history.replaceState({v:V,i:HI},'')}
else{HI++;VS.length=HI;VS[HI]=V;history.pushState({v:V,i:HI},'')}
LASTV=V}
const keepH=()=>history.pushState({v:V,i:HI},'');
function obBackStep(){if(ADDING&&OBS===1)return cancelAdd();if(OBS===2)OB2={l:$('#ol').value,pl:+$('#op').value,cl:+$('#oy').value};onb(Math.max(0,OBS-1))}
window.addEventListener('popstate',e=>{if(IGN>0){IGN--;return}const st=e.state||{},i=st.i!=null?st.i:0;
if(!$('#pick').hidden||!$('#lock').hidden){keepH();return}
if(!$('#sh').hidden){closeSheet();keepH();return}
if(!$('#ob').hidden){if(S.profile&&S.cycles.length){keepH();return}if(OBS>0){HI=i;obBackStep()}return}
POP=true;HI=i;V=VS[i]||'home';render();POP=false});
 function render(){navHist();const m={qr,bbt,gkick,gweight,gbag,prof,notif,home,cal,diary,stats,more,hist,phases,learn,help,sett};$('#main').innerHTML='<div class="pg">'+m[V]()+'</div>';if(V==='qr')qrRefresh();$$('.nv button').forEach(b=>b.classList.toggle('on',b.dataset.v===(NAVOF[V]||V)));window.scrollTo(0,0)}
const back=()=>'<div class="top" style="margin-bottom:14px"><button data-a="go" data-v="more" aria-label="Voltar">‹</button></div>';
const chips=(g,arr,sel,single)=>'<div class="chips">'+arr.map(x=>`<button type="button" class="chip${(single?sel===x:(sel||[]).includes(x))?' on':''}" data-a="chip" data-g="${g}" data-s="${single?1:0}">${esc(x)}</button>`).join('')+'</div>';
