/* ===== cor personalizada ===== */
const CUSPS=['#b4566f','#e11d48','#f97316','#d97706','#16a34a','#0d9488','#0ea5e9','#2f80ed','#6366f1','#8b5cf6','#c026d3','#64748b'];
function cusPv(h){const{H,S,ac,g1}=cusB(h),el=$('#cuspv');if(el)el.style.background='linear-gradient(135deg,'+hsl(H,S,g1)+','+hsl(H,S,ac)+','+hsl(H,S,Math.min(75,ac+12))+')';const i=$('#cusin');if(i&&i.value!==h)i.value=h;$$('.cus-ps button').forEach(b=>b.classList.toggle('on',b.dataset.c===h))}
function cusSet(h){h=cHx(h);localStorage.setItem('ff-color','custom');localStorage.setItem('ff-custom',h);theme();cusPv(h);$$('.swt button').forEach(b=>b.classList.toggle('on',b.dataset.v==='custom'));const cb=$('.swt button[data-v="custom"]');if(cb)cb.style.background=h;const n=$('#colN');if(n)n.textContent='Personalizada'}
function cusSheet(){const cur=localStorage.getItem('ff-color')==='custom'?cusHex():'#b4566f';sheet(`<h2 style="margin-top:0">Cor personalizada</h2><p class="mu">Escolhe a cor principal. O resto da app ajusta-se sozinho, no modo claro e no escuro.</p><div class="cus-pv" id="cuspv"></div><div class="cus-ps">${CUSPS.map(c=>`<button type="button" data-a="cusPick" data-c="${c}" aria-label="${c}" style="background:${c}"></button>`).join('')}</div><label class="cus-in"><span>Outra cor</span><input type="color" id="cusin" value="${cur}"></label><button class="btn" data-a="cusDone">Concluído</button>`);cusPv(cur)}
A.cusPick=e=>cusSet(e.dataset.c);
A.cusDone=()=>{closeSheet();render()};
document.addEventListener('input',e=>{if(e.target&&e.target.id==='cusin')cusSet(e.target.value)});
/* ===== temperatura basal ===== */
const fT=v=>Number(v).toFixed(2).replace('.',',');
function bbtRows(){const lc=lastC(),end=today();let st=lc?lc.start:n2d(d2n(end)-45);if(d2n(end)-d2n(st)>60)st=n2d(d2n(end)-60);return Object.keys(S.logs).filter(k=>S.logs[k].bbt&&k>=st&&k<=end).sort().map(k=>({d:k,t:S.logs[k].bbt}))}
function bbtOvu(r){for(let i=6;i+2<r.length;i++){const w=r.slice(i-6,i),base=Math.max(...w.map(x=>x.t));if(r[i].t>base&&r[i+1].t>base&&r[i+2].t>=base+.2&&d2n(r[i+2].d)-d2n(w[0].d)<=16)return{cover:base,d:n2d(d2n(r[i].d)-1)}}return null}
function bbtChart(r,ov){if(r.length<2)return'';const W=340,H=190,L=36,R=10,T=14,B=26,ts=r.map(x=>x.t);let mn=Math.min(...ts),mx=Math.max(...ts);if(ov){mn=Math.min(mn,ov.cover);mx=Math.max(mx,ov.cover)}mn=Math.floor((mn-.1)*10)/10;mx=Math.ceil((mx+.1)*10)/10;if(mx-mn<.6)mx=Math.round((mn+.6)*10)/10;
const d0=d2n(r[0].d),sp=Math.max(1,d2n(r[r.length-1].d)-d0),X=d=>L+(d2n(d)-d0)/sp*(W-L-R),Y=t=>T+(mx-t)/(mx-mn)*(H-T-B);let g='';
for(let i=0;i<=3;i++){const v=mx-i*(mx-mn)/3,y=Y(v).toFixed(1);g+=`<line x1="${L}" x2="${W-R}" y1="${y}" y2="${y}" style="stroke:var(--ln)" stroke-width="1"/><text x="${L-5}" y="${+y+3}" text-anchor="end" font-size="9" style="fill:var(--mu)">${v.toFixed(1).replace('.',',')}</text>`}
let ex='';if(ov){const y=Y(ov.cover).toFixed(1),xo=X(ov.d).toFixed(1);ex=`<line x1="${L}" x2="${W-R}" y1="${y}" y2="${y}" style="stroke:var(--wn)" stroke-width="1.2" stroke-dasharray="5 4"/><line x1="${xo}" x2="${xo}" y1="${T}" y2="${H-B}" style="stroke:var(--ac)" stroke-width="1.2" stroke-dasharray="2 3"/><text x="${xo}" y="${T-3}" text-anchor="middle" font-size="9" style="fill:var(--wn)">Ov.</text>`}
const pts=r.map(x=>X(x.d).toFixed(1)+','+Y(x.t).toFixed(1)).join(' '),dots=r.map(x=>`<circle cx="${X(x.d).toFixed(1)}" cy="${Y(x.t).toFixed(1)}" r="3.2" stroke-width="2" style="fill:var(--cd);stroke:var(--ac)"/>`).join('');
const xl=[r[0].d,r[Math.floor((r.length-1)/2)].d,r[r.length-1].d].filter((v,i,a)=>a.indexOf(v)===i).map(d=>`<text x="${X(d).toFixed(1)}" y="${H-8}" text-anchor="${d===r[r.length-1].d?'end':'middle'}" font-size="9" style="fill:var(--mu)">${dm(d)}</text>`).join('');
return `<svg class="bbt-c" viewBox="0 0 ${W} ${H}" role="img" aria-label="Gráfico da temperatura basal">${g}${ex}<polyline points="${pts}" fill="none" stroke-width="2.2" stroke-linejoin="round" stroke-linecap="round" style="stroke:var(--ac)"/>${dots}${xl}</svg>`}
function bbt(){const r=bbtRows(),ov=bbtOvu(r),td=(S.logs[today()]||{}).bbt,all=Object.keys(S.logs).filter(k=>S.logs[k].bbt).sort().reverse().slice(0,30),n=r.length,avg=n?r.reduce((a,x)=>a+x.t,0)/n:0;
const st=ov?sTx('Ovulação provável por volta de '+formatDate(ov.d,1),'Subida de temperatura sustentada acima de '+fT(ov.cover)+' °C. É uma estimativa.'):sTx(n<10?'Ainda poucos registos':'Sem subida sustentada visível','Regista todas as manhãs. Com cerca de 10 registos seguidos o gráfico já consegue indicar a subida.');
return PGH('Temperatura basal','more')
+'<p class="mu" style="margin:0 4px 14px">Mede ao acordar, antes de te levantares e sempre à mesma hora. Depois da ovulação a temperatura sobe cerca de 0,2 a 0,5 °C e mantém-se mais alta até à menstruação.</p>'
+`<div class="sg pad">${fld('bbd','Data','cal','type="date" max="'+today()+'"',today())}${fld('bbv','Temperatura (°C)','thermo','type="number" step="0.01" min="34" max="40" inputmode="decimal"',td||'')}<div id="pr" class="ob-err" role="alert"></div><button class="btn" data-a="bbtSave">Guardar</button></div>`
+sec('Este ciclo',n>=2?bbtChart(r,ov):emp('thermo','Ainda sem gráfico','Guarda a temperatura em pelo menos 2 dias para ver a curva.'),1)
+'<div class="sg"><div class="sr" style="cursor:default">'+sIc('calh')+st+'</div>'+(n?`<div class="sr" style="cursor:default">${sIc('chart')}${sTx('Média deste ciclo','Último registo: '+fT(r[n-1].t)+' °C')}<b class="sv-b">${fT(avg)} °C</b></div>`:'')+'</div>'
+'<p class="mu" style="margin:10px 4px 0;font-size:12px">Estimativa informativa. Não serve como método contracetivo. Em caso de dúvida, fala com um profissional de saúde.</p>'
+(all.length?sec('Histórico',all.map(k=>`<div class="sr" style="cursor:default">${sTx(formatDate(k))}<b class="sv-b">${fT(S.logs[k].bbt)} °C</b><button type="button" class="bbt-x" data-a="bbtDel" data-d="${k}" aria-label="Apagar">${ic('trash')}</button></div>`).join('')):'')}
A.bbtSave=async()=>{const d=String($('#bbd').value||'').trim(),v=parseFloat(String($('#bbv').value||'').replace(',','.'));if(!validDate(d)||d>today())return fe('bbd','Escolhe uma data válida.','pr');if(!(v>=34&&v<=40))return fe('bbv','Indica uma temperatura entre 34 e 40 °C.','pr');const l=S.logs[d]||{date:d};l.bbt=Math.round(v*100)/100;await dbPut('logs',l);await load();render();toast('Temperatura guardada ♥')};
A.bbtDel=async e=>{const d=e.dataset.d,l=S.logs[d];if(!l)return;delete l.bbt;if(Object.keys(l).filter(k=>k!=='date').length)await dbPut('logs',l);else await dbDel('logs',d);await load();render();toast('Registo apagado')};
document.addEventListener('change',e=>{if(e.target&&e.target.id==='bbd'){const l=S.logs[e.target.value],i=$('#bbv');if(i)i.value=l&&l.bbt?l.bbt:''}});
A.pickShow=()=>{showPicker($('#lock').hidden?'app':'lock')};
A.pickClose=()=>{$('#pick').hidden=true;if(PICKFROM==='lock')showLock();else{$('#nav').hidden=false;render()}};
A.pickP=async e=>{await switchTo(e.dataset.id);await afterSwitch()};
A.addP=async()=>{const l=PRget()||[];if(l.length>=4)return;PREVID=localStorage.getItem('ff-active');const id='p'+Date.now();l.push({id,db:'fanny-app-'+id});PRset(l);ADDING=true;await switchTo(id);await afterSwitch()};
A.qrImg=()=>A.qrWeb();
A.qrScan=()=>{if(hasNativeScan()){try{median.barcode.scan().then(r=>{if(r&&r.success&&r.code)scanShow(String(r.code));else toast('Leitura cancelada')}).catch(()=>toast('Não foi possível abrir a câmara'))}catch(e){A.qrWeb()}return}A.qrWeb()};
A.qrWeb=()=>{sheet(`<h2 style="margin-top:0">Ler código QR</h2><div class="scn"><video id="qv" playsinline muted autoplay></video><i class="scn-f"></i></div><p class="mu" id="scm" style="text-align:center;margin:12px 0">A iniciar a câmara…</p><button class="btn s" data-a="qrPick">${ic('img')}Escolher imagem</button><button class="btn s" data-a="close">Cancelar</button><input type="file" id="qfi" accept="image/*" hidden>`);scanStart()};
A.qrPick=()=>{const i=$('#qfi');if(i)i.click()};
A.qrCopy=async()=>{try{await navigator.clipboard.writeText(LASTQ);toast('Copiado ♥')}catch(e){toast('Não foi possível copiar')}};
A.qrSave=()=>{const q=QR.make(qrText());if(!q)return toast('Informação a mais para o código.');QR.canvas(q,10).toBlob(b=>saveFile(b,'my-cycle-qr.png'),'image/png')};
A.qrShare=()=>{const q=QR.make(qrText());if(!q)return toast('Informação a mais para o código.');QR.canvas(q,10).toBlob(b=>{LASTF={blob:b,name:'my-cycle-qr.png'};A.fShare()},'image/png')};
A.photo=()=>{const p=S.profile;sheet(`<h2 style="margin-top:0">Foto de perfil</h2><div class="ph-pv"${avSt(p)}>${p.photo?'':esc(p.name.trim().charAt(0).toUpperCase())}</div><button class="btn" data-a="phCam">${ic('camera')}Tirar foto</button><button class="btn s" data-a="phGal">${ic('img')}Escolher da galeria</button>${p.photo?'<button class="btn s" data-a="phDel">Remover foto</button>':''}<button class="btn s" data-a="close">Cancelar</button><input type="file" id="phc" accept="image/*" capture="user" hidden><input type="file" id="phg" accept="image/*" hidden>`)};
A.phCam=()=>{const i=$('#phc');if(i)i.click()};A.phGal=()=>{const i=$('#phg');if(i)i.click()};
A.phDel=async()=>{delete S.profile.photo;delete S.profile.thumb;await dbPut('profile',S.profile);profSync();closeSheet();render();toast('Foto removida')};
A.obPhoto=()=>{const i=$('#obf');if(i)i.click()};
A.birth=()=>sheet(`<h2 style="margin-top:0">O teu bebé nasceu</h2>${fld('bd','Data do parto','cal','type="date" max="'+today()+'"',today())}${fld('bn','Nome do bebé (opcional)','heart','maxlength="30" autocomplete="off" autocapitalize="words"','')}<div id="pr" class="ob-err" role="alert"></div><button class="btn" data-a="saveBirth">Guardar</button><button class="btn s" data-a="close">Cancelar</button>`);
A.saveBirth=async()=>{const d=$('#bd').value;if(!validDate(d)||d2n(d)>d2n(today())||d2n(today())-d2n(d)>365)return fe('bd','Indica uma data válida (no último ano).','pr');S.cfg.post={on:true,date:d,baby:$('#bn').value.trim().slice(0,30)};if(S.cfg.preg)S.cfg.preg.on=false;await saveCfg();V='home';msgOK('Parabéns! ♥')};
A.postOff=async()=>{if(S.cfg.post)S.cfg.post.on=false;await saveCfg();V='home';render();toast('Modo pós-parto terminado.')};
A.cnt=async e=>{const k=e.dataset.k,d=today(),l=S.logs[d]||{date:d};l[k]=Math.max(0,Math.min(99,(l[k]||0)+ +e.dataset.n));await dbPut('logs',l);await load();render()};
A.kick=async e=>{const d=today(),l=S.logs[d]||{date:d};l.kicks=Math.max(0,Math.min(500,(l.kicks||0)+ +e.dataset.n));await dbPut('logs',l);await load();render()};
A.saveW=async()=>{const v=parseFloat($('#wk').value.replace(',','.'));if(!(v>=30&&v<=250))return $('#pr').textContent='Indica um peso válido (30 a 250 kg).';const d=today(),l=S.logs[d]||{date:d};l.weight=Math.round(v*10)/10;await dbPut('logs',l);await load();render();toast('Peso guardado ♥')};
/*PDF*/
function reportPdf(){
const T=(localStorage.getItem('ff-color')==='custom'?cusPal(cusHex()):PAL[localStorage.getItem('ff-color')||'rosa'])||PAL.rosa,W=595,H=842,M=40,P=[],HW=[278,278,355,556,556,889,667,191,333,333,389,584,278,333,278,278,556,556,556,556,556,556,556,556,556,556,278,278,584,584,584,556,1015,667,667,722,722,667,611,778,722,278,500,667,556,833,722,778,667,778,722,667,611,722,667,944,667,667,611,278,278,278,469,556,333,556,556,500,556,556,278,556,556,222,222,500,222,833,556,556,556,556,333,500,278,556,500,722,500,500,500,334,260,334,584];
const col=h=>[1,3,5].map(i=>(parseInt(h.substr(i,2),16)/255).toFixed(3)).join(' '),nb=t=>String(t).normalize('NFD').replace(/[\u0300-\u036f]/g,'').replace(/[^\x20-\x7E]/g,''),
tw=(t,z,b)=>{let w=0;for(const c of nb(t))w+=HW[c.charCodeAt(0)-32];return w*(b===1?1.07:1)*z/1000},
MP={'♥':'','→':'->','–':'-','—':'-','“':'"','”':'"'},ex=t=>String(t).replace(/[♥→–—“”]/g,m=>MP[m]).replace(/[^\x20-\xFF]/g,'').replace(/[\\()]/g,'\\$&'),
fd=t=>t.slice(8)+'/'+t.slice(5,7)+'/'+t.slice(0,4);
let o,y,pg=0;
const Tx=(t,x,yy,z,b,c)=>o.push(`BT /F${b===2?3:b?2:1} ${z} Tf ${col(c||'#3A2430')} rg ${x.toFixed(1)} ${(H-yy).toFixed(1)} Td (${ex(t)}) Tj ET`),
Rc=(x,yy,w,h,c)=>o.push(`${col(c)} rg ${x.toFixed(1)} ${(H-yy-h).toFixed(1)} ${w.toFixed(1)} ${h.toFixed(1)} re f`),
Ln=(x1,y1,x2,y2,c,wd,d)=>o.push(`${d||'[] 0'} d ${col(c)} RG ${wd} w ${x1.toFixed(1)} ${(H-y1).toFixed(1)} m ${x2.toFixed(1)} ${(H-y2).toFixed(1)} l S [] 0 d`),
Ci=(cx,cy,r,c)=>{const k=r*.5523,X=cx,Y=H-cy;o.push(`${col(c)} rg ${X+r} ${Y} m ${X+r} ${Y+k} ${X+k} ${Y+r} ${X} ${Y+r} c ${X-k} ${Y+r} ${X-r} ${Y+k} ${X-r} ${Y} c ${X-r} ${Y-k} ${X-k} ${Y-r} ${X} ${Y-r} c ${X+k} ${Y-r} ${X+r} ${Y-k} ${X+r} ${Y} c f`)},
wr=(t,w,z,b)=>{const out=[];let cur='';String(t).split(/\s+/).forEach(wd=>{const nx=cur?cur+' '+wd:wd;if(tw(nx,z,b)>w&&cur){out.push(cur);cur=wd}else cur=nx});if(cur)out.push(cur);return out.length?out:['']};
const np=()=>{o=[];P.push(o);pg++;if(pg===1){o.push(`q 0 ${H-122} ${W} 122 re W n`);Rc(0,0,W,122,T.d);Ci(548,6,96,T.c1);Ci(470,112,52,T.c2);o.push('Q');Rc(0,122,W,4,T.m);Tx('My Cycle+',M,62,30,1,'#FFFFFF');Tx('Relatório completo',M,84,12,0,T.lt);const p=S.profile,r1=p.name,r2=p.age+' anos  ·  '+p.city,r3='Gerado em '+formatDate(today());Tx(r1,W-M-tw(r1,12,1),56,12,1,'#FFFFFF');Tx(r2,W-M-tw(r2,9.5),74,9.5,0,T.lt);Tx(r3,W-M-tw(r3,9.5),90,9.5,0,T.lt);y=152}else{Rc(0,0,W,30,T.d);Rc(0,30,W,2.5,T.m);Tx('My Cycle+  ·  Relatório completo',M,20,9,1,'#FFFFFF');const n=S.profile.name;Tx(n,W-M-tw(n,9),20,9,0,T.lt);y=58}};
const need=h=>{if(y+h>H-62){np();return true}return false};
const h2=t=>{need(70);Tx(t,M,y+14,13.5,1,T.d);Rc(M,y+21,26,2.5,T.m);y+=36};
const cards=a=>{need(84);const k=a.length,w=(W-2*M-(k-1)*10)/k;a.forEach(([l,v,sb],i)=>{const x=M+i*(w+10);Rc(x,y,w,64,T.s);Rc(x,y,3.5,64,T.m);Tx(l.toUpperCase(),x+12,y+18,7,1,'#8D7280');let z=17;while(tw(v,z,1)>w-20&&z>8)z--;Tx(v,x+12,y+42,z,1,T.d);if(sb)Tx(sb,x+12,y+56,7.5,0,'#8D7280')});y+=82};
const th=cols=>{Rc(M,y,W-2*M,22,T.d);cols.forEach(([t,x])=>Tx(t,x,y+14.5,8.5,1,'#FFFFFF'));y+=22};
const tbl=(cols,rows)=>{th(cols);rows.forEach((r,i)=>{if(need(r.h+2))th(cols);Rc(M,y,W-2*M,r.h,i%2?'#FFFFFF':T.s);r.t.forEach(([x,ls,z,b])=>ls.forEach((l,k)=>Tx(l,x,y+13+k*11,z,b,b?T.d:'#3A2430')));y+=r.h});Ln(M,y,W-M,y,T.ln,.8);y+=14};
const La=cycleLens(),pd=S.cycles.map(calculatePeriodDuration).filter(Boolean),preg=S.cfg.preg&&S.cfg.preg.on;
np();h2('Resumo');
cards([['Média do ciclo',(La.length?calculateAverageCycle():S.profile.cycleLen)+' dias',La.length?'baseada em '+La.length+(La.length>1?' ciclos':' ciclo'):'valor inicial'],['Menstruação',avgPeriod()+' dias',pd.length?'média registada':'valor inicial'],['Ciclos registados',String(S.cycles.length),La.length?'mais curto '+Math.min(...La)+' · mais longo '+Math.max(...La):''],[preg?'Gravidez':PP()?'Pós-parto':'Próxima menstruação',preg||PP()?'em curso':formatDate(calculateNextPeriod(),1),preg||PP()?'':'previsão aproximada']]);
if(preg){const g=S.cfg.preg,n=Math.max(0,d2n(today())-d2n(g.lmp)),nx=apptDates().find(a=>d2n(a.d)>=d2n(today())),ws=Object.keys(S.logs).filter(k=>S.logs[k].weight).sort(),lw=ws.length?S.logs[ws[ws.length-1]].weight:null;h2('Gravidez (estimativa)');cards([['Idade gestacional',Math.floor(n/7)+' sem '+n%7+' d','estimativa'],['Parto provável',formatDate(n2d(d2n(g.lmp)+280),1),'pode variar'],['Próxima consulta',nx?formatDate(nx.d,1):'-',nx&&nx.t?'às '+nx.t:''],['Último peso',lw?String(lw).replace('.',',')+' kg':'-','']])}
h2('Duração dos ciclos');
if(!La.length){Tx('Regista pelo menos duas menstruações para ver o gráfico.',M,y+10,9.5,2,'#8D7280');y+=34}
else{need(150);const L=La.slice(-8),n=L.length,bw=W-2*M,avg=calculateAverageCycle(),mx=Math.max(...L,avg)+3,base=y+104,hh=72,gw=bw/n;Rc(M,y,bw,134,T.s);
L.forEach((v,i)=>{const bh=v/mx*hh,x=M+i*gw+gw/2-14;Rc(x,base-bh,28,bh,i===n-1?T.d:T.l);const t=String(v);Tx(t,x+14-tw(t,8.5,1)/2,base-bh+14,8.5,1,'#FFFFFF');const lb='#'+(La.length-n+i+1);Tx(lb,x+14-tw(lb,8)/2,base+15,8,0,'#8D7280')});
const ay=base-avg/mx*hh,lt='média '+avg+' d';Ln(M+8,ay,M+bw-8,ay,T.d,.7,'[3 3] 0');Tx(lt,M+bw-10-tw(lt,7.5),y+16,7.5,2,T.d);y+=152}
const lg=Object.keys(S.logs).sort().map(k=>({k,...S.logs[k]})).filter(l=>l.mood||l.flow||l.pain||l.notes||l.weight||l.water||(l.symptoms||[]).length||(l.q||[]).length);
const cn=a=>{const m={};a.forEach(x=>{if(x)m[x]=(m[x]||0)+1});return Object.entries(m).sort((a,b)=>b[1]-a[1])};
const symAll=cn(lg.flatMap(l=>l.symptoms||[])),feelAll=cn([...lg.map(l=>l.mood),...lg.flatMap(l=>(l.q||[]).map(x=>(Q.find(q=>q[0]===x)||[])[2]))]),flowAll=cn(lg.map(l=>l.flow));
const pdays=lg.filter(l=>l.pain>0),pavg=pdays.length?pdays.reduce((a,l)=>a+l.pain,0)/pdays.length:0,pmax=pdays.length?Math.max(...pdays.map(l=>l.pain)):0;
const wdays=lg.filter(l=>l.water>0),wavg=wdays.length?wdays.reduce((a,l)=>a+l.water,0)/wdays.length:0;
const f1=v=>v.toFixed(1).replace('.',',');
const hbars=(title,items)=>{if(!items.length)return;const it=items.slice(0,8),mx=Math.max(...it.map(x=>x[1]));need(34+it.length*20);Tx(title,M,y+10,9.5,1,T.d);y+=22;it.forEach(([l,n])=>{const lb=l.length>24?l.slice(0,23)+'.':l,bw=Math.max(5,n/mx*(W-2*M-215));Tx(lb,M,y+11,9,0,'#3A2430');Rc(M+135,y+2,bw,12,T.l);Tx(n+(n>1?' dias':' dia'),M+135+bw+6,y+11,8.5,1,T.d);y+=20});y+=10};
if(lg.length||La.length){h2('Análise do período registado');const reg=La.length>1?Math.max(...La)-Math.min(...La):null;
cards([['Regularidade',reg==null?'-':(reg<=7?'Regular':'Variável'),reg==null?'precisa de 2 ou mais ciclos':'variação de '+reg+' dias'],['Dor média',pdays.length?f1(pavg)+'/10':'-',pdays.length?'máxima '+pmax+'/10 · '+pdays.length+' dias':'sem registos'],['Dias com registos',String(lg.length),lg.length?'desde '+fd(lg[0].k):''],['Água por dia',wdays.length?f1(wavg)+' copos':'-',wdays.length?'média em '+wdays.length+' dias':'sem registos']]);
hbars('Sintomas mais frequentes',symAll);hbars('Humor e como me senti',feelAll);hbars('Fluxo registado',flowAll);
const phaseOf=k=>{const n=d2n(k);let ci=-1;S.cycles.forEach((c,i)=>{if(d2n(c.start)<=n)ci=i});if(ci<0)return null;const c=S.cycles[ci],nx=S.cycles[ci+1],cl=nx?d2n(nx.start)-d2n(c.start):calculateAverageCycle(),day=n-d2n(c.start)+1;if(day>cl+10)return null;const pl=calculatePeriodDuration(c)||avgPeriod(),ov=cl-14;return day<=pl?0:day<=ov-2?1:day<=ov+1?2:3};
const PN=['Menstruação','Fase folicular','Ovulação (estimativa)','Fase lútea'],PH2=PN.map(()=>({d:0,p:[],s:{}}));
lg.forEach(l=>{if(!(l.pain||l.mood||l.flow||(l.symptoms||[]).length||(l.q||[]).length))return;const i=phaseOf(l.k);if(i==null)return;const o2=PH2[i];o2.d++;if(l.pain)o2.p.push(l.pain);(l.symptoms||[]).forEach(s=>o2.s[s]=(o2.s[s]||0)+1)});
if(PH2.some(o2=>o2.d)){need(110);Tx('Sintomas e dor por fase do ciclo',M,y+10,9.5,1,T.d);y+=22;tbl([['Fase',M+12],['Dias registados',M+150],['Dor média',M+240],['Sintomas mais comuns',M+310]],PH2.map((o2,i)=>{const top=Object.entries(o2.s).sort((a,b)=>b[1]-a[1]).slice(0,3).map(x=>x[0]).join(', ')||'-',ls=wr(top,200,8.5);return{h:Math.max(21,9+ls.length*11),t:[[M+12,[PN[i]],9,1],[M+150,[String(o2.d)],9.5,0],[M+240,[o2.p.length?f1(o2.p.reduce((a,b)=>a+b)/o2.p.length)+'/10':'-'],9.5,0],[M+310,ls,8.5,0]]}}))}}
const wk=Object.keys(S.logs).filter(k=>S.logs[k].weight).sort();
if(wk.length&&(preg||(S.cfg.preg&&S.cfg.preg.lmp)||PP())){h2('Peso');const ws=wk.map(k=>S.logs[k].weight),mn=Math.floor(Math.min(...ws))-1,mx2=Math.ceil(Math.max(...ws))+1,cw=W-2*M-52,ch=84,x0=M+40,y0=y+14;need(160);Rc(M,y,W-2*M,112,T.s);[[mx2,0],[(mn+mx2)/2,.5],[mn,1]].forEach(([v,f])=>{Ln(x0,y0+f*ch,x0+cw,y0+f*ch,T.ln,.6);Tx(String(Math.round(v)),M+10,y0+f*ch+3,7.5,0,'#8D7280')});
const pt=wk.map((k,i)=>({x:x0+(wk.length>1?i/(wk.length-1):.5)*cw,y:y0+ch-(ws[i]-mn)/(mx2-mn)*ch}));for(let i=1;i<pt.length;i++)Ln(pt[i-1].x,pt[i-1].y,pt[i].x,pt[i].y,T.d,1.6);pt.forEach(p=>Ci(p.x,p.y,2.8,T.d));y+=126;
tbl([['Data',M+12],['Peso',M+140],['Variação',M+260]],wk.slice(-12).reverse().map(k=>{const w=S.logs[k].weight,d=w-ws[0];return{h:20,t:[[M+12,[fd(k)],9.5,0],[M+140,[f1(w)+' kg'],9.5,1],[M+260,[k===wk[0]?'-':(d>0?'+':'')+f1(d)+' kg'],9.5,0]]}}))}
if(preg||(S.cfg.preg&&S.cfg.preg.lmp)){const ap=apptDates().filter(a=>d2n(a.d)>=d2n(today())).slice(0,6),kk=[1,2,3,4,5,6,7].map(i=>(S.logs[n2d(d2n(today())-i)]||{}).kicks).filter(v=>v>0);
if(ap.length||kk.length){h2('Consultas e movimentos do bebé');if(kk.length)cards([['Movimentos por dia',f1(kk.reduce((a,b)=>a+b)/kk.length),'média dos últimos 7 dias'],['Dias com registo',String(kk.length),'nos últimos 7 dias']]);if(ap.length)tbl([['Data',M+12],['Hora',M+140],['Notas',M+220]],ap.map(a=>({h:20,t:[[M+12,[fd(a.d)],9.5,0],[M+140,[a.t||'-'],9.5,0],[M+220,[a.n||'Consulta pré-natal'],9.5,0]]})))}}
if(S.cfg.post&&S.cfg.post.date){const g=S.cfg.post,n=Math.max(0,d2n(today())-d2n(g.date)),L7=k=>[1,2,3,4,5,6,7].map(i=>(S.logs[n2d(d2n(today())-i)]||{})[k]).filter(v=>v>0),fe2=L7('feeds'),di=L7('diapers');
h2('Pós-parto');cards([['Data do parto',formatDate(g.date,1),g.baby?String(g.baby):''],['Idade do bebé',babyAge(n),'desde o parto'],['Mamadas por dia',fe2.length?f1(fe2.reduce((a,b)=>a+b)/fe2.length):'-','últimos 7 dias'],['Fraldas por dia',di.length?f1(di.reduce((a,b)=>a+b)/di.length):'-','últimos 7 dias']])}
h2('Histórico de ciclos');
tbl([['#',M+12],['Início',M+52],['Fim',M+170],['Menstruação',M+290],['Ciclo',M+410]],S.cycles.map((c,i)=>{const l=calculateCycleLength(i),d=calculatePeriodDuration(c);return{h:21,t:[[M+12,['#'+(i+1)],9,1],[M+52,[fd(c.start)],9.5,0],[M+170,[c.end?fd(c.end):'em curso'],9.5,0],[M+290,[d?d+' dias':'-'],9.5,0],[M+410,[l?l+' dias':'em curso'],9.5,0]]}}).reverse());
const ks=Object.keys(S.logs).filter(k=>{const l=S.logs[k];return l.mood||l.flow||l.pain||l.notes||l.weight||(l.symptoms||[]).length||(l.q||[]).length}).sort().reverse().slice(0,60);
h2('Diário (últimos registos)');
if(!ks.length){Tx('Sem registos no diário.',M,y+10,9.5,2,'#8D7280');y+=30}
else tbl([['Data',M+12],['Humor',M+84],['Fluxo',M+152],['Dor',M+204],['Sintomas e notas',M+240]],ks.map(k=>{const l=S.logs[k],tx=[...(l.q||[]).map(x=>Q.find(q=>q[0]===x)[2]),...(l.symptoms||[]),l.weight&&'Peso '+l.weight+' kg'].filter(Boolean).join(', ')+(l.notes?(l.q&&l.q.length||(l.symptoms||[]).length||l.weight?' · ':'')+'"'+l.notes+'"':''),ls=wr(tx||'-',265,8.5);return{h:Math.max(21,9+ls.length*11),t:[[M+12,[fd(k)],9,1],[M+84,[l.mood||'-'],9,0],[M+152,[l.flow||'-'],9,0],[M+204,[l.pain?l.pain+'/10':'-'],9,0],[M+240,ls,8.5,0]]}}));
need(72);Rc(M,y,W-2*M,56,T.t);Rc(M,y,3.5,56,T.d);wr('As previsões, os dias férteis e as fases do ciclo são estimativas e podem variar. Não são método contraceptivo. Este relatório serve para organização pessoal e não substitui a avaliação de um profissional de saúde.',W-2*M-30,8.5,2).forEach((l,k)=>Tx(l,M+14,y+19+k*12,8.5,2,T.dd));y+=70;
const N=P.length;P.forEach((ops,i)=>{o=ops;Rc(M,H-46,W-2*M,.6,T.ln);Tx('My Cycle+  ·  Documento pessoal e confidencial',M,H-30,7.5,0,'#8D7280');const t='Página '+(i+1)+' de '+N;Tx(t,W-M-tw(t,7.5),H-30,7.5,0,'#8D7280')});
let s='%PDF-1.4\n';const off=[],add=(n,b)=>{off[n]=s.length;s+=n+' 0 obj\n'+b+'\nendobj\n'};
add(1,'<</Type/Catalog/Pages 2 0 R>>');add(2,`<</Type/Pages/Count ${N}/Kids[${P.map((_,i)=>(6+2*i)+' 0 R').join(' ')}]>>`);
['Helvetica','Helvetica-Bold','Helvetica-Oblique'].forEach((f,i)=>add(3+i,`<</Type/Font/Subtype/Type1/BaseFont/${f}/Encoding/WinAnsiEncoding>>`));
P.forEach((ops,i)=>{const c=ops.join('\n');add(6+2*i,`<</Type/Page/Parent 2 0 R/MediaBox[0 0 595 842]/Resources<</Font<</F1 3 0 R/F2 4 0 R/F3 5 0 R>>>>/Contents ${7+2*i} 0 R>>`);add(7+2*i,`<</Length ${c.length}>>\nstream\n${c}\nendstream`)});
const x0=s.length,MX=6+2*N;s+=`xref\n0 ${MX}\n0000000000 65535 f \n`+off.slice(1).map(v=>String(v).padStart(10,'0')+' 00000 n \n').join('')+`trailer\n<</Size ${MX}/Root 1 0 R>>\nstartxref\n${x0}\n%%EOF`;return Uint8Array.from(s,c=>c.charCodeAt(0))}
/*ENDPDF*/
/* bloqueio automático */
document.addEventListener('contextmenu',e=>{if(!/INPUT|TEXTAREA/.test(e.target.tagName))e.preventDefault()});document.addEventListener('selectstart',e=>{if(!/INPUT|TEXTAREA/.test(e.target.tagName||''))e.preventDefault()});
let lastAct=Date.now();['click','touchstart','keydown'].forEach(e=>document.addEventListener(e,()=>{lastAct=Date.now()},{passive:true}));
function chkLock(){const m=S.cfg.alock;if(!m||!S.cfg.pin||!S.profile||$('#nav').hidden||!$('#lock').hidden)return;if(Date.now()-lastAct>m*60000){closeSheet();showLock()}}
setInterval(chkLock,5000);document.addEventListener('visibilitychange',()=>{if(document.hidden){if(REV){REV=false;clearTimeout(revT)}}else chkLock()});
(async()=>{theme();profInit();if(!NB&&'serviceWorker' in navigator){let had=!!navigator.serviceWorker.controller;navigator.serviceWorker.addEventListener('controllerchange',()=>{if(had)location.reload();had=true});navigator.serviceWorker.register('sw.js').catch(()=>{})}
const wait=new Promise(r=>setTimeout(r,7000));let ok=true;try{await openDB();await load()}catch(e){ok=false}await wait;$('#splash').hidden=true;
if(!ok){$('#main').innerHTML='<div class="pg"><div class="card"><h3>Armazenamento indisponível</h3><p class="mu">Este navegador não permite guardar dados (modo privado?). Abre a app num separador normal.</p></div></div>';return}
if((PRget()||[]).length>1)return showPicker('boot');
if(!S.profile||!S.cycles.length)return onb(0);
if(S.cfg.pin)showLock();else enter()})();
