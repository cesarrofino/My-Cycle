/* My Cycle+ · ligação à app Android.
   Só faz algo quando corre dentro da app nativa (window.NB = AndroidBridge). */
(function () {
  'use strict';
  var NB = window.NB;
  if (!NB) return;

  var tmr = null;

  /* ---------- Notificações: envia os dados do ciclo para o Android ---------- */
  function doSync() {
    try {
      if (typeof S === 'undefined' || !S.profile || !S.cfg) return;
      var r = S.cfg.rem || {};
      var lc = (typeof lastC === 'function') ? lastC() : null;
      var avg = 28;
      try { if (lc) avg = calculateAverageCycle(); } catch (e) {}
      var preg = !!(S.cfg.preg && S.cfg.preg.on);
      var d = today();
      var appts = [];
      if (preg) {
        try {
          appts = apptDates().map(function (a) {
            return { id: String(a.id), d: a.d, t: a.t || '', n: a.n || '' };
          });
        } catch (e) {}
      }
      var payload = {
        pid: localStorage.getItem('ff-active') || 'p1',
        name: String(S.profile.name || '').trim().split(/\s+/)[0] || '',
        lastStart: lc ? lc.start : '',
        avg: avg,
        pregOn: preg,
        postOn: !!(typeof PP === 'function' && PP()),
        hide: !!(S.cfg.hideName || S.cfg.discreet),
        lmp: preg ? String((S.cfg.preg || {}).lmp || '') : '',
        accent: (function () { try { var v = (getComputedStyle(document.documentElement).getPropertyValue('--g1') || '').trim(); return /^#[0-9a-f]{6}$/i.test(v) ? v : ''; } catch (e) { return ''; } })(),
        rem: {
          before: r.before !== false,
          start: r.start !== false,
          sym: r.sym !== false,
          late: r.late !== false,
          days: r.days || 2,
          hour: r.hour || 9,
          symh: r.symh || 20
        },
        appts: appts,
        logged: (S.logs && S.logs[d]) ? [d] : [],
        profiles: (typeof PRget === 'function' ? (PRget() || []) : []).map(function (x) { return x.id; })
      };
      NB.syncReminders(JSON.stringify(payload));
    } catch (e) { /* nunca deve partir a app */ }
  }
  window.syncNative = function () {
    clearTimeout(tmr);
    tmr = setTimeout(doSync, 900);
  };

  /* ---------- Biometria nativa ---------- */
  window.nbBio = function (title) {
    return new Promise(function (res) {
      var id = 'b' + Date.now();
      window.__bio = function (i, ok) {
        if (i === id) { window.__bio = null; res(!!ok); }
      };
      try { NB.biometricAuth(id, title); } catch (e) { window.__bio = null; res(false); }
    });
  };

  /* ---------- Guardar / partilhar ficheiros ---------- */
  function blobToB64(b) {
    return new Promise(function (res, rej) {
      var fr = new FileReader();
      fr.onload = function () { var s = String(fr.result); res(s.slice(s.indexOf(',') + 1)); };
      fr.onerror = function () { rej(fr.error); };
      fr.readAsDataURL(b);
    });
  }
  window.nbFile = async function (mode) {
    try {
      var f = LASTF;
      if (!f) return;
      var b64 = await blobToB64(f.blob);
      var mime = f.blob.type || 'application/octet-stream';
      if (mode === 'save') {
        if (NB.saveFile(f.name, mime, b64)) { toast('Guardado em Transferências ♥'); return; }
        toast('A abrir partilha…');
      }
      NB.shareFile(f.name, mime, b64);
    } catch (e) {
      toast('Não foi possível guardar o ficheiro');
    }
  };

  /* ---------- Atalhos e toques nas notificações ---------- */
  window.nativeAction = function (a) {
    if (a !== 'day' && a !== 'start') return;
    var nav = document.getElementById('nav');
    if (nav && !nav.hidden && typeof dayS === 'function') {
      if (a === 'day') dayS(today()); else startP();
    } else {
      window.__qa = a; /* será usado quando a app abrir (depois do PIN) */
    }
  };

  /* ---------- Ecrã "Notificações com a app fechada" ---------- */
  function row(ok, t, d, act, btn) {
    return '<div style="display:flex;align-items:center;gap:10px;padding:10px 0;border-bottom:1px solid var(--ln)">' +
      '<div style="flex:1"><b>' + (ok ? '✅ ' : '⚠️ ') + t + '</b><br><small class="mu">' + d + '</small></div>' +
      (ok ? '' : '<button class="btn s" style="width:auto;margin:0;padding:8px 14px" data-a="' + act + '">' + btn + '</button>') +
      '</div>';
  }
  function setupSheet() {
    var st = {};
    try { st = JSON.parse(NB.status()); } catch (e) {}
    sheet(
      '<h2 id="nsb" style="margin-top:0">Notificações com a app fechada</h2>' +
      '<p class="mu">Para os avisos chegarem sempre, mesmo com a app fechada, confirma estes pontos.</p>' +
      row(st.notif, 'Permissão de notificações', 'Necessária para mostrar os avisos.', 'nsNotif', 'Permitir') +
      row(st.exact, 'Alarmes exatos', 'Garante que o aviso chega à hora certa.', 'nsExact', 'Permitir') +
      row(st.battery, 'Sem restrições de bateria', 'Evita que o Android atrase ou bloqueie os avisos (importante em Xiaomi, Huawei, Samsung, Oppo…).', 'nsBat', 'Ajustar') +
      '<button class="btn" data-a="nsTest" style="margin-top:14px">Testar agora</button>' +
      '<button class="btn s" data-a="nsTest1">Testar daqui a 1 minuto (fecha a app)</button>' +
      '<button class="btn s" data-a="close">Fechar</button>'
    );
  }
  A.nsSetup = setupSheet;
  A.nsNotif = function () { NB.requestNotificationPermission(); };
  A.nsExact = function () { NB.openExactAlarmSettings(); };
  A.nsBat = function () { NB.openBatterySettings(); };
  A.nsTest = function () { NB.sendTest(0); toast('Notificação enviada ♥'); };
  A.nsTest1 = function () {
    NB.sendTest(60);
    toast('Teste agendado. Fecha a app e espera 1 minuto ♥');
  };

  window.nativeResume = function () {
    if (document.getElementById('nsb')) setupSheet();
    window.syncNative();
  };

  /* chamado quando a app abre (depois do PIN, se houver) */
  window.nbEnter = function () {
    try { NB.requestNotificationPermissionOnce(); } catch (e) {}
    window.syncNative();
    bars();
  };

  /* ---------- Cores da barra de estado / navegação ---------- */
  function bars() {
    try {
      var m = document.querySelector('meta[name=theme-color]');
      var bg = (getComputedStyle(document.documentElement).getPropertyValue('--bg') || '').trim();
      NB.setBars(m && m.content ? m.content : '#7a2b45', /^#/.test(bg) ? bg : '#fbf4f0');
    } catch (e) {}
  }
  try {
    new MutationObserver(bars).observe(document.documentElement, { attributes: true });
    var mt = document.querySelector('meta[name=theme-color]');
    if (mt) new MutationObserver(bars).observe(mt, { attributes: true });
    if (window.matchMedia) {
      var mq = matchMedia('(prefers-color-scheme: dark)');
      if (mq.addEventListener) mq.addEventListener('change', bars);
    }
  } catch (e) {}
  window.addEventListener('load', function () { setTimeout(bars, 300); });
})();
