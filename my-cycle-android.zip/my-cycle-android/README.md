# My Cycle+ (Android · Kotlin + JavaScript)

A tua app web (HTML/CSS/JavaScript puro) empacotada numa app Android nativa em Kotlin.
As notificações são agendadas pelo Android (`AlarmManager` + `WorkManager`), por isso chegam
**com a app fechada**, depois de reiniciar o telemóvel e depois de atualizar a app.

## Gerar o APK no GitHub (sem instalar nada)

1. Cria um repositório no GitHub e envia **todo o conteúdo desta pasta**.
2. Vai ao separador **Actions → Build APK**. Corre automaticamente em cada push (ou clica em *Run workflow*).
3. Quando acabar (±5 min), abre a execução e descarrega **MyCycle-APK** em *Artifacts*:
   - `MyCycle-release.apk` → o que deves instalar
   - `MyCycle-debug.apk`   → versão de testes
4. (Opcional) Cria uma tag `v1.0.1` e o APK fica também em *Releases*.

No telemóvel: abre o APK e permite "instalar de fontes desconhecidas".

## Chave de assinatura fixa (para atualizar sem perder dados)

Sem chave fixa, cada build é assinada com uma chave diferente e o Android recusa instalar por cima
(é preciso desinstalar, e isso apaga os dados). Para evitar isso, cria 3 segredos no GitHub
(*Settings → Secrets and variables → Actions → New repository secret*):

| Segredo | Valor |
|---|---|
| `KEYSTORE_BASE64` | conteúdo do ficheiro `.jks` em base64 (uma só linha) |
| `KEYSTORE_PASSWORD` | palavra-passe da chave |
| `KEY_ALIAS` | `mycycle` |

O workflow deteta os segredos e assina o APK (debug e release) com essa chave. **Nunca** comites o `.jks`
(está no `.gitignore`) e guarda uma cópia segura: se a perderes, só consegues instalar desinstalando.

## Estrutura do projeto

```
app/src/main/
├── java/com/mycycle/app/     Kotlin: MainActivity, NativeBridge (ponte JS↔Android),
│                             Engine/Scheduler/Notifier/Receivers (notificações), Store, Widgets
├── assets/www/
│   ├── index.html            só o esqueleto da página
│   ├── styles.css            todo o CSS
│   ├── qr.js                 gerador de códigos QR
│   ├── js/                   lógica da app, carregada por ordem (01 → 08):
│   │   01-perfis-db          perfis e base de dados (IndexedDB)
│   │   02-calculos-seguranca previsões do ciclo, PIN e biometria
│   │   03-tema-render        tema/cores e renderização
│   │   04-paginas-principais início, calendário, diário, estatísticas
│   │   05-qr-mais-definicoes QR, menu Mais e Definições
│   │   06-registo-importar   registo de ciclos e importação
│   │   07-arranque           arranque, notificações da app, bloqueio
│   │   08-extras-basal-pdf   cor personalizada, temperatura basal, PDF
│   └── native.js             liga a app à ponte Android (só corre dentro da app)
└── res/                      ícones, temas, widget, atalhos
```

Os ficheiros em `js/` partilham o mesmo âmbito global (scripts clássicos): mantém a **ordem** dos
`<script>` em `index.html`.

## Novidades da versão 1.2.0
- **3 notificações por dia** (manhã 08:00, tarde 14:00, noite 21:00), com horas e interruptor nas Definições.
- **Lembrete mensal de cópia de segurança** (dia 1, 10:00).
- **Ocultar nos apps recentes** (Definições → Privacidade): bloqueia capturas de ecrã.
- Canal de notificações novo (o antigo podia estar silenciado no telemóvel).
- Removida a ligação Bluetooth/Health Connect ao relógio.
- Assinatura com chave fixa (ver acima) e workflow que compila a partir do ZIP **ou** do código na raiz.
- CSS e JavaScript separados em ficheiros.

## Novidades da versão 1.1.0
- **Widget no ecrã inicial** (*My Cycle+*): mostra o dia do ciclo, quantos dias faltam para a menstruação
  (ou "atrasada há X dias") e tem o botão **Registar hoje**. Em gravidez mostra as semanas.
  Usa a cor do tema e, com o modo discreto ativo, não mostra dados. Atualiza sozinho à meia-noite,
  e sempre que registas algo. Para adicionar: toque longo no ecrã inicial → Widgets → My Cycle+.
- **Temperatura basal** (*Mais → Temperatura basal* e no registo do dia): guarda a temperatura de cada
  manhã, desenha a curva do ciclo e estima a ovulação quando deteta uma subida sustentada
  (regra dos 3 dias acima dos 6 anteriores). É apenas uma estimativa informativa.
- **Cores personalizadas** (*Definições → Aparência → Cor → círculo colorido*): escolhe uma das cores
  sugeridas ou qualquer outra; a app gera o resto da paleta para o modo claro e para o escuro
  (com contraste automático para o texto branco). Também se aplica ao relatório em PDF.

## Notificações – o que a app faz
- Menstruação a caminho (X dias antes), "Já começou?", atraso (1, 7 e 14 dias)
- Lembrete diário de sintomas (não aparece se já registaste nesse dia)
- Consultas pré-natais (2 dias, 1 dia e no próprio dia)
- Horas configuráveis em *Definições → Notificações*
- Alarmes exatos + reagendamento no arranque, mudança de hora/fuso e atualização da app
- Rede de segurança (WorkManager) a cada 6 horas
- Em *Definições → Notificações → "Notificações com a app fechada"* há um ecrã para
  verificar permissões, retirar restrições de bateria e **testar** (agora ou daqui a 1 minuto, com a app fechada)

> Em telemóveis Xiaomi/Huawei/Oppo/Samsung, aceita também "Início automático"/"Sem restrições de bateria"
> nas definições da app, para o sistema nunca matar os avisos.

## Estrutura
```
app/src/main/assets/www/   → a tua app (index.html, app.js, qr.js, native.js)
app/src/main/java/...      → Kotlin: MainActivity, NativeBridge, Engine, Scheduler, Widgets, receivers
```
`native.js` liga o JavaScript ao Android (notificações, ficheiros, biometria, cores das barras).
Fora da app Android (num navegador) a app web continua a funcionar como antes.

## Alterar a versão
`app/build.gradle.kts` → `versionCode` e `versionName`.

## Notas
- Os dados ficam só no telemóvel (sem Internet, sem `allowBackup`). Desinstalar a app apaga tudo: faz backup (JSON) antes.
- A permissão `USE_EXACT_ALARM` é ideal para instalar por APK; se publicares na Google Play, a política da loja pode pedir justificação.
